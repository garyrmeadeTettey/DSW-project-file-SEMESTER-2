import React from "react";
import DataGridTable from "pages/DataGridTable";
import User from "pages/User";
import Form from "pages/Form";
import TableOne from "pages/TableOne";
import Income from "pages/Income";
import Table from "pages/Table";
import HospitalSurvey from "pages/HospitalSurvey";
import Dashboard from "pages/Dashboard";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "pages/Home";
import NotFound from "pages/NotFound";

const ProjectRoutes = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="*" element={<NotFound />} />
        <Route path="/hospitalsurvey" element={<HospitalSurvey />} />
        <Route path="/table" element={<Table />} />
        <Route path="/income" element={<Income />} />
        <Route path="/tableone" element={<TableOne />} />
        <Route path="/form" element={<Form />} />
        <Route path="/user" element={<User />} />
        <Route path="/datagridtable" element={<DataGridTable />} />
        <Route path="/dhiwise-dashboard" element={<Home />} />
      </Routes>
    </Router>
  );
};

export default ProjectRoutes;
