import React from "react";
import PropTypes from "prop-types";

const shapes = {
  RoundedBorder16: "rounded-radius16",
  RoundedBorder5: "rounded-radius5",
  RoundedBorder20: "rounded-radius20",
  icbRoundedBorder8: "rounded-radius8",
  icbRoundedBorder20: "rounded-radius20",
  icbRoundedBorder4: "rounded-radius4",
};
const variants = {
  OutlinePurple100: "bg-purple_300 shadow-bs text-white_A700",
  FillBlue50: "bg-blue_50 text-bluegray_900_ab",
  OutlineDeeppurple200a3: "bg-teal_200 shadow-bs2 text-white_A700",
  OutlineTeal200: "bg-teal_200 shadow-bs3 text-white_A700",
  OutlineRed300: "bg-red_300 shadow-bs4 text-white_A700",
  FillRed300: "bg-red_300 text-white_A700",
  FillTeal200: "bg-teal_200 text-white_A700",
  FillPurple300: "bg-purple_300 text-white_A700",
  OutlineDeeppurple100a3: "bg-white_A700 shadow-bs1 text-black_900",
  OutlineDeeppurple100cc:
    "bg-purple_300 border border-deep_purple_100_cc border-solid text-white_A700",
  OutlineDeeppurple100cc1_2:
    "bg-gray_50 border border-deep_purple_100_cc border-solid text-bluegray_900_7f",
  icbOutlineDeeppurple200a3: "bg-white_A700 shadow-bs2",
  icbOutlineDeeppurple100a3: "bg-white_A700 shadow-bs1",
  icbOutlineDeeppurple100a31_2: "bg-white_A700_87 shadow-bs1",
  icbOutlineGray20099: "border border-gray_200_99 border-solid",
  icbOutlineGray200: "border border-gray_200 border-solid",
  icbOutlineDeeppurple200a31_2: "bg-purple_300 shadow-bs2",
  icbOutlineIndigo50:
    "bg-purple_300 border border-indigo_50 border-solid shadow-bs2",
};
const sizes = {
  sm: "p-[4px]",
  md: "lg:p-[4px] xl:p-[5px] 2xl:p-[6px] p-[7px]",
  lg: "p-[10px] lg:p-[7px] xl:p-[8px] 2xl:p-[9px]",
  xl: "xl:p-[11px] 2xl:p-[12px] p-[14px] 3xl:p-[15px] lg:p-[9px]",
  smIcn: "xl:p-[4px] lg:p-[4px] 2xl:p-[5px] p-[6px]",
  mdIcn: "p-[10px] lg:p-[7px] xl:p-[8px] 2xl:p-[9px]",
  lgIcn: "xl:p-[11px] 2xl:p-[12px] p-[14px] 3xl:p-[15px] lg:p-[9px]",
};

const Button = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  shape,
  variant,
  size,
  ...restProps
}) => {
  return (
    <button
      className={`${className} ${shapes[shape] || ""} ${
        variants[variant] || ""
      } ${sizes[size] || ""} common-button `}
      {...restProps}
    >
      {!!leftIcon && leftIcon}
      {children}
      {!!rightIcon && rightIcon}
    </button>
  );
};

Button.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  shape: PropTypes.oneOf([
    "RoundedBorder16",
    "RoundedBorder5",
    "RoundedBorder20",
    "icbRoundedBorder8",
    "icbRoundedBorder20",
    "icbRoundedBorder4",
  ]),
  variant: PropTypes.oneOf([
    "OutlinePurple100",
    "FillBlue50",
    "OutlineDeeppurple200a3",
    "OutlineTeal200",
    "OutlineRed300",
    "FillRed300",
    "FillTeal200",
    "FillPurple300",
    "OutlineDeeppurple100a3",
    "OutlineDeeppurple100cc",
    "OutlineDeeppurple100cc1_2",
    "icbOutlineDeeppurple200a3",
    "icbOutlineDeeppurple100a3",
    "icbOutlineDeeppurple100a31_2",
    "icbOutlineGray20099",
    "icbOutlineGray200",
    "icbOutlineDeeppurple200a31_2",
    "icbOutlineIndigo50",
  ]),
  size: PropTypes.oneOf(["sm", "md", "lg", "xl", "smIcn", "mdIcn", "lgIcn"]),
};
Button.defaultProps = {
  className: "",
  shape: "",
  variant: "icbOutlineDeeppurple200a3",
  size: "smIcn",
};

export { Button };
