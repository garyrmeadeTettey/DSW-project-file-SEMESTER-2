import { ErrorMessage } from "../../components/ErrorMessage";
import React from "react";
import PropTypes from "prop-types";

const variants = {
  UnderLineBluegray90063: "border-b-[1px] border-bluegray_900_63",
  FillBlue50: "bg-blue_50",
  UnderLineBluegray900: "border-b-[1px] border-bluegray_900",
};

const sizes = {
  sm: "xl:p-[10px] 2xl:p-[11px] p-[13px] 3xl:p-[14px] lg:p-[9px]",
  md: "xl:pb-[11px] 2xl:pb-[12px] pb-[14px] 3xl:pb-[15px] lg:pb-[9px]",
  lg: "pb-[11px] lg:pb-[7px] xl:pb-[8px] 2xl:pb-[9px]",
  xl: "lg:pb-[21px] xl:pb-[24px] 2xl:pb-[27px] pb-[31px] 3xl:pb-[33px]",
};

const Input = React.forwardRef(
  (
    {
      wrapClassName = "",
      className = "",
      name,
      placeholder,
      type = "text",
      children,
      errors = [],
      label = "",
      prefix,
      suffix,
      variant,
      size,
      ...restProps
    },
    ref
  ) => {
    return (
      <>
        <div
          className={`${wrapClassName}  ${variants[variant] || ""} ${
            sizes[size] || ""
          }`}
        >
          {!!label && label}
          {!!prefix && prefix}
          <input
            ref={ref}
            className={`${className} bg-transparent border-0`}
            type={type}
            name={name}
            placeholder={placeholder}
            {...restProps}
          />
          {!!suffix && suffix}
        </div>
        {!!errors && <ErrorMessage errors={errors} />}
      </>
    );
  }
);

Input.propTypes = {
  wrapClassName: PropTypes.string,
  className: PropTypes.string,
  name: PropTypes.string,
  placeholder: PropTypes.string,
  type: PropTypes.string,
  variant: PropTypes.oneOf([
    "UnderLineBluegray90063",
    "FillBlue50",
    "UnderLineBluegray900",
  ]),
  size: PropTypes.oneOf(["sm", "md", "lg", "xl"]),
};
Input.defaultProps = {
  wrapClassName: "",
  className: "",
  name: "",
  placeholder: "",
  type: "text",
  variant: "UnderLineBluegray90063",
  size: "md",
};

export { Input };
