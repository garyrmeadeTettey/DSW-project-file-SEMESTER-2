import React from "react";

import { List, Column, Row, Text, Stack, Img } from "components";

const IncomePage = () => {
  return (
    <>
      <List
        className="font-lato lg:gap-[30px] xl:gap-[34px] 2xl:gap-[38px] 3xl:gap-[46px] grid grid-cols-2 min-h-[auto] mx-[auto] w-[100%]"
        orientation="horizontal"
      >
        <Column className="bg-white_A700 items-center justify-center lg:p-[22px] xl:p-[25px] 2xl:p-[28px] 3xl:p-[34px] rounded-radius8 shadow-bs6 w-[100%]">
          <Row className="items-end justify-between xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] w-[99%]">
            <Text className="font-bold lg:text-[20px] xl:text-[23px] 2xl:text-[25px] 3xl:text-[31px] text-gray_900 tracking-ls1 w-[auto]">
              $ 100,000
            </Text>
            <Text className="font-bold mb-[3px] xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[12px] xl:text-[13px] 2xl:text-[15px] 3xl:text-[18px] text-gray_500 tracking-ls1 w-[auto]">
              Income in current month
            </Text>
          </Row>
          <Row className="mb-[2px] lg:mt-[22px] xl:mt-[25px] 2xl:mt-[28px] 3xl:mt-[34px] w-[100%]">
            <Column className="items-end w-[9%]">
              <Text className="font-bold lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                $100,000
              </Text>
              <Column className="lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] w-[80%]">
                <Text className="font-bold lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $80,000
                </Text>
                <Text className="font-bold lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $60,000
                </Text>
                <Text className="font-bold lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $40,000
                </Text>
                <Text className="font-bold lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $20,000
                </Text>
                <Text className="font-bold lg:ml-[26px] xl:ml-[30px] 2xl:ml-[33px] 3xl:ml-[40px] lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $0
                </Text>
              </Column>
            </Column>
            <Stack className="lg:h-[186px] xl:h-[213px] 2xl:h-[239px] 3xl:h-[287px] lg:ml-[12px] xl:ml-[13px] 2xl:ml-[15px] 3xl:ml-[18px] xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] w-[88%]">
              <Stack
                className="absolute bg-cover bg-repeat lg:h-[163px] xl:h-[186px] 2xl:h-[210px] 3xl:h-[251px] inset-x-[0] lg:pr-[22px] xl:pr-[25px] 2xl:pr-[28px] 3xl:pr-[34px] top-[0] w-[100%]"
                style={{ backgroundImage: "url('images/img_group102.svg')" }}
              >
                <Img
                  src="images/img_secondary.svg"
                  className="absolute 3xl:h-[113px] lg:h-[73px] xl:h-[84px] 2xl:h-[94px] left-[0] top-[9%] w-[95%]"
                  alt="secondary"
                />
              </Stack>
              <Row className="absolute bottom-[0] inset-x-[0] items-center justify-end mx-[auto] 3xl:px-[10px] lg:px-[7px] xl:px-[8px] 2xl:px-[9px] w-[99%]">
                <Column className="items-center w-[23%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-blue_201 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] 3xl:mt-[112px] lg:mt-[72px] xl:mt-[83px] 2xl:mt-[93px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    1 July
                  </Text>
                </Column>
                <Column className="items-center w-[22%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-blue_201 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] lg:mt-[122px] xl:mt-[139px] 2xl:mt-[157px] 3xl:mt-[188px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    8 July
                  </Text>
                </Column>
                <Column className="items-center w-[23%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-blue_201 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] lg:mt-[49px] xl:mt-[56px] 2xl:mt-[63px] 3xl:mt-[76px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    16 July
                  </Text>
                </Column>
                <Column className="items-center w-[23%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-blue_201 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] xl:mt-[113px] 2xl:mt-[127px] 3xl:mt-[152px] lg:mt-[98px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    24 July
                  </Text>
                </Column>
                <Column className="items-center w-[8%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-blue_201 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] 3xl:mt-[102px] lg:mt-[66px] xl:mt-[76px] 2xl:mt-[85px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    31 July
                  </Text>
                </Column>
              </Row>
            </Stack>
          </Row>
        </Column>
        <Column className="bg-white_A700 items-center justify-center lg:p-[22px] xl:p-[25px] 2xl:p-[28px] 3xl:p-[34px] rounded-radius8 shadow-bs6 w-[100%]">
          <Row className="items-end justify-between xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] w-[99%]">
            <Text className="font-bold lg:text-[20px] xl:text-[23px] 2xl:text-[25px] 3xl:text-[31px] text-gray_900 tracking-ls1 w-[auto]">
              $ 25,000
            </Text>
            <Text className="font-bold mb-[3px] xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[12px] xl:text-[13px] 2xl:text-[15px] 3xl:text-[18px] text-gray_500 tracking-ls1 w-[auto]">
              Income in current week
            </Text>
          </Row>
          <Row className="mb-[2px] lg:mt-[22px] xl:mt-[25px] 2xl:mt-[28px] 3xl:mt-[34px] w-[100%]">
            <Column className="items-end w-[9%]">
              <Text className="font-bold lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                $100,000
              </Text>
              <Column className="lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] w-[80%]">
                <Text className="font-bold lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $80,000
                </Text>
                <Text className="font-bold lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $60,000
                </Text>
                <Text className="font-bold lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $40,000
                </Text>
                <Text className="font-bold lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $20,000
                </Text>
                <Text className="font-bold lg:ml-[26px] xl:ml-[30px] 2xl:ml-[33px] 3xl:ml-[40px] lg:mt-[20px] xl:mt-[23px] 2xl:mt-[25px] 3xl:mt-[31px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                  $0
                </Text>
              </Column>
            </Column>
            <Stack className="lg:h-[186px] xl:h-[213px] 2xl:h-[239px] 3xl:h-[287px] lg:ml-[12px] xl:ml-[13px] 2xl:ml-[15px] 3xl:ml-[18px] xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] w-[88%]">
              <Stack
                className="absolute bg-cover bg-repeat lg:h-[163px] xl:h-[186px] 2xl:h-[210px] 3xl:h-[251px] inset-x-[0] mx-[auto] lg:pr-[21px] xl:pr-[24px] 2xl:pr-[27px] 3xl:pr-[32px] top-[0] w-[99%]"
                style={{ backgroundImage: "url('images/img_group102.svg')" }}
              >
                <Img
                  src="images/img_secondary_yellow_700.svg"
                  className="absolute bottom-[4%] xl:h-[109px] 2xl:h-[123px] 3xl:h-[147px] lg:h-[95px] left-[0] w-[95%]"
                  alt="secondary One"
                />
              </Stack>
              <Row className="absolute bottom-[0] inset-x-[0] items-center justify-end mx-[auto] 3xl:px-[10px] lg:px-[7px] xl:px-[8px] 2xl:px-[9px] w-[99%]">
                <Column className="items-center w-[15%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-amber_200 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] lg:mt-[100px] xl:mt-[115px] 2xl:mt-[129px] 3xl:mt-[155px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    25 July
                  </Text>
                </Column>
                <Column className="items-center w-[15%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-amber_200 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] lg:mt-[52px] xl:mt-[60px] 2xl:mt-[67px] 3xl:mt-[80px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    26 July
                  </Text>
                </Column>
                <Column className="items-center w-[15%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-amber_200 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] xl:mt-[101px] 2xl:mt-[114px] 3xl:mt-[137px] lg:mt-[88px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    27 July
                  </Text>
                </Column>
                <Column className="items-center w-[15%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-amber_200 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] lg:mt-[63px] xl:mt-[72px] 2xl:mt-[81px] 3xl:mt-[98px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    28 July
                  </Text>
                </Column>
                <Column className="items-center w-[15%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-amber_200 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] lg:mt-[120px] xl:mt-[137px] 2xl:mt-[154px] 3xl:mt-[185px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    29 July
                  </Text>
                </Column>
                <Column className="items-center w-[15%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-amber_200 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    30 July
                  </Text>
                </Column>
                <Column className="items-center w-[8%]">
                  <Column className="3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] xl:w-[6px] lg:w-[6px] 2xl:w-[7px] 3xl:w-[9px]">
                    <div className="bg-amber_200 h-[2px] outline outline-[3px] outline-white_A700 rounded-radius3 w-[100%]"></div>
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] ml-[3px] 2xl:mt-[105px] 3xl:mt-[126px] lg:mt-[81px] xl:mt-[93px] w-[17%]"></div>
                  </Column>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-gray_500 tracking-ls1 w-[auto]">
                    31 July
                  </Text>
                </Column>
              </Row>
            </Stack>
          </Row>
        </Column>
      </List>
    </>
  );
};

export default IncomePage;
