import React from "react";

import { Column, Row, Text, Img, Stack, Line, List } from "components";

const HospitalSurveyPage = () => {
  return (
    <>
      <Column className="bg-white_A700 font-lato items-center justify-end mx-[auto] lg:p-[24px] xl:p-[27px] 2xl:p-[31px] 3xl:p-[37px] shadow-bs6 w-[100%]">
        <Row className="xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] w-[100%]">
          <Text className="font-bold lg:text-[20px] xl:text-[23px] 2xl:text-[25px] 3xl:text-[31px] text-gray_900 tracking-ls1 w-[auto]">
            Hospital Survey
          </Text>
          <Img
            src="images/img_vector2_yellow_700.svg"
            className="2xl:h-[3px] xl:h-[3px] lg:h-[3px] 3xl:h-[4px] 3xl:ml-[1031px] lg:ml-[667px] xl:ml-[763px] 2xl:ml-[859px] xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] w-[2%]"
            alt="VectorTwo"
          />
          <Text className="font-bold 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] mt-[1px] lg:text-[12px] xl:text-[13px] 2xl:text-[15px] 3xl:text-[18px] text-gray_500 tracking-ls1 w-[auto]">
            Patients 2019
          </Text>
          <Img
            src="images/img_vector1_blue_A700.svg"
            className="2xl:h-[3px] xl:h-[3px] lg:h-[3px] 3xl:h-[4px] lg:ml-[48px] xl:ml-[55px] 2xl:ml-[62px] 3xl:ml-[74px] xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] w-[2%]"
            alt="VectorOne"
          />
          <Text className="font-bold 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] mt-[1px] lg:text-[12px] xl:text-[13px] 2xl:text-[15px] 3xl:text-[18px] text-gray_500 tracking-ls1 w-[auto]">
            Patients 2020
          </Text>
        </Row>
        <Row className="lg:mt-[29px] xl:mt-[33px] 2xl:mt-[37px] 3xl:mt-[45px] w-[100%]">
          <Column className="w-[2%]">
            <Text className="font-bold lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
              300
            </Text>
            <Text className="font-bold lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[43px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
              250
            </Text>
            <Text className="font-bold lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[43px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
              200
            </Text>
            <Text className="font-bold ml-[3px] lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[43px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
              150
            </Text>
            <Text className="font-bold ml-[3px] lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[43px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
              100
            </Text>
            <Text className="font-bold 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[43px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
              50
            </Text>
            <Text className="font-bold lg:ml-[14px] xl:ml-[16px] 2xl:ml-[18px] 3xl:ml-[21px] lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[43px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
              0
            </Text>
          </Column>
          <Stack className="lg:h-[267px] xl:h-[305px] 2xl:h-[343px] 3xl:h-[412px] 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] w-[97%]">
            <Stack
              className="absolute bg-cover bg-repeat lg:h-[244px] xl:h-[279px] 2xl:h-[313px] 3xl:h-[376px] px-[1px] top-[0] w-[100%]"
              style={{ backgroundImage: "url('images/img_group1.svg')" }}
            >
              <Img
                src="images/img_graphics.png"
                className="absolute bottom-[0] lg:h-[197px] xl:h-[226px] 2xl:h-[254px] 3xl:h-[304px] inset-x-[0] mx-[auto] w-[94%]"
                alt="graphics"
              />
            </Stack>
            <Column className="absolute inset-x-[1%] px-[4px] w-[98%]">
              <Stack className="lg:h-[242px] xl:h-[276px] 2xl:h-[311px] 3xl:h-[373px] lg:ml-[519px] xl:ml-[594px] 2xl:ml-[668px] 3xl:ml-[802px] w-[6%]">
                <Stack className="absolute lg:h-[242px] xl:h-[276px] 2xl:h-[311px] 3xl:h-[373px] inset-x-[44%] w-[13%]">
                  <Line className="absolute bg-blue_201 lg:h-[242px] xl:h-[276px] 2xl:h-[311px] 3xl:h-[373px] right-[38%] w-[1px]" />
                  <div className="absolute bg-white_A700 border-blue_A700 border-bw15 border-solid xl:h-[10px] 2xl:h-[11px] 3xl:h-[13px] lg:h-[9px] rounded-radius50 shadow-bs7 top-[36%] 2xl:w-[10px] 3xl:w-[12px] lg:w-[8px] xl:w-[9px]"></div>
                </Stack>
                <Img
                  src="images/img_map.svg"
                  className="absolute lg:h-[16px] xl:h-[18px] 2xl:h-[20px] 3xl:h-[24px] right-[31%] top-[38%] w-[22%]"
                  alt="map"
                />
                <Column
                  className="absolute bg-cover bg-repeat items-center 2xl:p-[10px] 3xl:p-[12px] lg:p-[8px] xl:p-[9px] top-[19%] w-[100%]"
                  style={{
                    backgroundImage: "url('images/img_graphselemen.svg')",
                  }}
                >
                  <Text className="font-bold mb-[2px] lg:text-[12px] xl:text-[13px] 2xl:text-[15px] 3xl:text-[18px] text-blue_A700 tracking-ls1 w-[auto]">
                    180
                  </Text>
                </Column>
              </Stack>
              <Row className="items-center mt-[1px] w-[100%]">
                <Column className="items-center w-[9%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[1%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-1
                  </Text>
                </Column>
                <Column className="items-center w-[9%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[1%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-2
                  </Text>
                </Column>
                <Column className="items-center w-[9%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[1%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-3
                  </Text>
                </Column>
                <Column className="items-center w-[9%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[1%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-4
                  </Text>
                </Column>
                <Column className="items-center w-[9%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[1%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-5
                  </Text>
                </Column>
                <List
                  className="lg:gap-[55px] xl:gap-[63px] 2xl:gap-[71px] 3xl:gap-[85px] grid grid-cols-2 min-h-[auto] w-[12%]"
                  orientation="horizontal"
                >
                  <Column className="items-center w-[100%]">
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[3%]"></div>
                    <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                      2020-6
                    </Text>
                  </Column>
                  <Column className="items-center w-[100%]">
                    <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[3%]"></div>
                    <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                      2020-7
                    </Text>
                  </Column>
                </List>
                <Column className="items-center lg:ml-[55px] xl:ml-[63px] 2xl:ml-[71px] 3xl:ml-[85px] w-[3%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[3%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-8
                  </Text>
                </Column>
                <Column className="items-center lg:ml-[55px] xl:ml-[63px] 2xl:ml-[71px] 3xl:ml-[85px] w-[3%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[3%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-9
                  </Text>
                </Column>
                <Column className="items-center lg:ml-[52px] xl:ml-[60px] 2xl:ml-[67px] 3xl:ml-[80px] w-[4%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[3%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-10
                  </Text>
                </Column>
                <Column className="items-center lg:ml-[49px] xl:ml-[56px] 2xl:ml-[63px] 3xl:ml-[76px] w-[4%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[3%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-11
                  </Text>
                </Column>
                <Column className="items-center lg:ml-[49px] xl:ml-[56px] 2xl:ml-[63px] 3xl:ml-[76px] w-[4%]">
                  <div className="bg-bluegray_103 3xl:h-[10px] xl:h-[7px] lg:h-[7px] 2xl:h-[8px] w-[3%]"></div>
                  <Text className="font-bold xl:mt-[6px] lg:mt-[6px] 2xl:mt-[7px] 3xl:mt-[9px] lg:text-[10px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] text-bluegray_101 tracking-ls1 w-[auto]">
                    2020-12
                  </Text>
                </Column>
              </Row>
            </Column>
          </Stack>
        </Row>
      </Column>
    </>
  );
};

export default HospitalSurveyPage;
