import React from "react";

import {
  Stack,
  Column,
  Slider,
  Text,
  Img,
  Row,
  List,
  Button,
} from "components";

const TablePage = () => {
  const sliderRef = React.useRef();
  const [sliderState, setsliderState] = React.useState(0);

  return (
    <>
      <Stack className="font-lato 3xl:h-[1078px] lg:h-[699px] xl:h-[799px] 2xl:h-[899px] mx-[auto] w-[100%]">
        <Column className="absolute bg-white_A700 lg:pb-[24px] xl:pb-[27px] 2xl:pb-[31px] 3xl:pb-[37px] rounded-radius8 shadow-bs6 w-[100%]">
          <Slider
            slidesToShow={1}
            activeIndex={sliderState}
            onSlideChanged={(e) => {
              setsliderState(e?.item);
            }}
            ref={sliderRef}
            className="w-[100%]"
            items={[...Array(3)].map(() => (
              <React.Fragment key={Math.random()}>
                <Column className="items-center justify-end">
                  <Stack className="3xl:h-[1047px] lg:h-[679px] xl:h-[776px] 2xl:h-[873px] w-[100%]">
                    <Stack className="absolute 3xl:h-[1047px] lg:h-[679px] xl:h-[776px] 2xl:h-[873px] w-[100%]">
                      <Column className="absolute items-center w-[100%]">
                        <Column className="bg-gray_200_6c lg:p-[20px] xl:p-[23px] 2xl:p-[25px] 3xl:p-[31px] rounded-bl-[0] rounded-br-[0] rounded-tl-[8px] rounded-tr-[8px] w-[100%]">
                          <Text className="font-bold mb-[1px] ml-[3px] lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                            Name
                          </Text>
                        </Column>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                        <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                      </Column>
                      <Stack className="absolute lg:h-[567px] xl:h-[648px] 2xl:h-[729px] 3xl:h-[874px] inset-y-[8%] w-[100%]">
                        <Img
                          src="images/img_dividers.svg"
                          className="absolute bottom-[0] lg:h-[2205px] xl:h-[2522px] 2xl:h-[2837px] 3xl:h-[3404px] w-[100%]"
                          alt="dividers"
                        />
                        <Row className="absolute h-[max-content] inset-[0] items-center justify-center m-[auto] w-[95%]">
                          <Column className="w-[96%]">
                            <Img
                              src="images/img_circle.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle"
                            />
                            <Img
                              src="images/img_circle_32X32.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle One"
                            />
                            <Img
                              src="images/img_circle_1.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle Two"
                            />
                            <Img
                              src="images/img_circle_2.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle Three"
                            />
                            <Img
                              src="images/img_circle_3.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle Four"
                            />
                            <Img
                              src="images/img_avatarcircle.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="avatarcircle"
                            />
                            <Img
                              src="images/img_circle_4.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle Five"
                            />
                            <Img
                              src="images/img_circle_5.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle Six"
                            />
                            <Img
                              src="images/img_circle_6.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle Seven"
                            />
                            <Img
                              src="images/img_circle_7.png"
                              className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                              alt="circle Eight"
                            />
                          </Column>
                          <List
                            className="lg:gap-[16px] xl:gap-[19px] 2xl:gap-[21px] 3xl:gap-[26px] grid grid-cols-2 min-h-[auto] w-[4%]"
                            orientation="horizontal"
                          >
                            <Column className="items-center w-[100%]">
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] w-[100%]"
                                alt="edit"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit One"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit Two"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit Three"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit Four"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit Five"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit Six"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit Seven"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit Eight"
                              />
                              <Img
                                src="images/img_edit.svg"
                                className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                                alt="edit Nine"
                              />
                            </Column>
                            <Column className="items-center my-[1px] w-[100%]">
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] w-[100%]"
                                alt="trash"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash One"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash Two"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash Three"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash Four"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash Five"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash Six"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash Seven"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash Eight"
                              />
                              <Img
                                src="images/img_trash.svg"
                                className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                                alt="trash Nine"
                              />
                            </Column>
                          </List>
                        </Row>
                      </Stack>
                    </Stack>
                    <List
                      className="absolute lg:gap-[24px] xl:gap-[27px] 2xl:gap-[31px] 3xl:gap-[37px] grid grid-cols-5 min-h-[auto] right-[9%] top-[3%] w-[68%]"
                      orientation="horizontal"
                    >
                      <Column className="justify-end w-[100%]">
                        <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                          Email
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          lesie.alexander@example.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          ronald.richards@example.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          jane.cooper@example.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          robert.fox@gmail.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          jenny.wilson@example.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          marshall.cook@example.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          stephanie.cook@example.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          marion.james@example.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          teresa.holland@example.com
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          zachary.marshall@example.com
                        </Text>
                        <Text className="font-normal xl:mt-[106px] 2xl:mt-[119px] 3xl:mt-[143px] lg:mt-[92px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                      </Column>
                      <Column className="justify-end mt-[1px] w-[100%]">
                        <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                          Date
                        </Text>
                        <Text className="font-normal lg:mt-[41px] xl:mt-[47px] 2xl:mt-[53px] 3xl:mt-[63px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/10/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/12/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/13/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/14/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/15/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/17/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/17/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/18/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/19/2020
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          10/20/2020
                        </Text>
                        <Text className="font-normal xl:mt-[108px] 2xl:mt-[122px] 3xl:mt-[146px] lg:mt-[94px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                      </Column>
                      <Column className="justify-end mt-[1px] w-[100%]">
                        <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                          Visit Time
                        </Text>
                        <Text className="font-normal lg:mt-[41px] xl:mt-[47px] 2xl:mt-[53px] 3xl:mt-[63px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          09:15-09:45am
                        </Text>
                        <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          12:00-12:45pm
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          01:15-01:45pm
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          02:00-02:45pm
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          12:00-12:45pm
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          01:15-01:45pm
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          02:00-02:45pm
                        </Text>
                        <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          09:15-09:45am
                        </Text>
                        <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          12:00-12:45pm
                        </Text>
                        <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          09:15-09:45am
                        </Text>
                        <Text className="font-normal xl:mt-[109px] 2xl:mt-[123px] 3xl:mt-[147px] lg:mt-[95px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                      </Column>
                      <Column className="justify-end mt-[1px] w-[100%]">
                        <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                          Doctor
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Jacob Jones
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Theresa Webb
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Jacob Jones
                        </Text>
                        <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Arlene McCoy
                        </Text>
                        <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Esther Howard
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Jacob Jones
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Theresa Webb
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Esther Howard
                        </Text>
                        <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Arlene McCoy
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dr. Arlene McCoy
                        </Text>
                        <Text className="font-normal xl:mt-[106px] 2xl:mt-[119px] 3xl:mt-[143px] lg:mt-[92px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                      </Column>
                      <Column className="justify-end w-[100%]">
                        <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                          Conditions
                        </Text>
                        <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Mumps Stage II
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Depression
                        </Text>
                        <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Arthritis
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Fracture
                        </Text>
                        <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Depression
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Dyslexia
                        </Text>
                        <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Hypothermia
                        </Text>
                        <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Sunburn
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Diarrhoea
                        </Text>
                        <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Arthritis
                        </Text>
                        <Text className="font-normal xl:mt-[109px] 2xl:mt-[123px] 3xl:mt-[147px] lg:mt-[95px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                        <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                          Large
                        </Text>
                      </Column>
                    </List>
                  </Stack>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                </Column>
              </React.Fragment>
            ))}
            Indicator={({ isActive }) => {
              if (isActive) {
                return <div className="" />;
              }
              return <div className="" role="button" tabIndex={0} />;
            }}
          />
          <Row className="items-center lg:ml-[24px] xl:ml-[27px] 2xl:ml-[31px] 3xl:ml-[37px] lg:mt-[19px] xl:mt-[21px] 2xl:mt-[24px] 3xl:mt-[29px] w-[16%]">
            <Button
              className="cursor-pointer flex lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] items-center justify-center lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
              onClick={() => sliderRef.current?.slidePrev()}
              shape="icbRoundedBorder4"
              size="mdIcn"
              variant="icbOutlineGray20099"
            >
              <Img
                src="images/img_arrowleft.svg"
                className="flex items-center justify-center"
                alt="arrowleft"
              />
            </Button>
            <Column className="bg-blue_A700 lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] items-center ml-[4px] 3xl:px-[10px] lg:px-[7px] xl:px-[8px] 2xl:px-[9px] rounded-radius4 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]">
              <Text className="font-normal mt-[3px] not-italic lg:text-[13px] xl:text-[15px] 2xl:text-[16px] 3xl:text-[20px] text-white_A700 tracking-ls1 w-[auto]">
                1
              </Text>
            </Column>
            <Column className="border border-gray_200 border-solid lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] items-center ml-[4px] 3xl:px-[10px] lg:px-[7px] xl:px-[8px] 2xl:px-[9px] rounded-radius4 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]">
              <Text className="font-normal mt-[3px] not-italic lg:text-[13px] xl:text-[15px] 2xl:text-[16px] 3xl:text-[20px] text-gray_900 tracking-ls1 w-[auto]">
                2
              </Text>
            </Column>
            <Column className="border border-gray_200 border-solid lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] items-center ml-[4px] 3xl:px-[10px] lg:px-[7px] xl:px-[8px] 2xl:px-[9px] rounded-radius4 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]">
              <Text className="font-normal mt-[3px] not-italic lg:text-[13px] xl:text-[15px] 2xl:text-[16px] 3xl:text-[20px] text-gray_900 tracking-ls1 w-[auto]">
                3
              </Text>
            </Column>
            <Button
              className="cursor-pointer flex lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] items-center justify-center ml-[4px] lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
              onClick={() => sliderRef.current?.slideNext()}
              shape="icbRoundedBorder4"
              size="mdIcn"
              variant="icbOutlineGray200"
            >
              <Img
                src="images/img_arrowright.svg"
                className="flex items-center justify-center"
                alt="arrowright"
              />
            </Button>
          </Row>
        </Column>
        <Column className="absolute bottom-[0] justify-end left-[6%] w-[14%]">
          <Text className="font-normal not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Leslie Alexander
          </Text>
          <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Ronald Richards
          </Text>
          <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Jane Cooper
          </Text>
          <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Robert Fox
          </Text>
          <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Jenny Wilson
          </Text>
          <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Marshall Cook
          </Text>
          <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Stephanie Cook
          </Text>
          <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Marion James
          </Text>
          <Text className="font-normal lg:mt-[41px] xl:mt-[47px] 2xl:mt-[53px] 3xl:mt-[63px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Teresa Holland
          </Text>
          <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Zachary Marshall
          </Text>
          <Text className="font-normal xl:mt-[106px] 2xl:mt-[119px] 3xl:mt-[143px] lg:mt-[92px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
        </Column>
      </Stack>
    </>
  );
};

export default TablePage;
