import React from "react";

import { Stack, Column, Row, Img, Button, Text, List, Line } from "components";

const UserPage = () => {
  return (
    <>
      <Stack className="bg-gradient  font-kanit xl:h-[1125px] 2xl:h-[1266px] 3xl:h-[1519px] lg:h-[984px] mx-[auto] lg:px-[41px] xl:px-[47px] 2xl:px-[53px] 3xl:px-[63px] w-[100%]">
        <Stack className="absolute 2xl:h-[1109px] 3xl:h-[1331px] lg:h-[862px] xl:h-[986px] inset-[0] justify-center m-[auto] w-[92%]">
          <Column className="absolute bg-white_A700_90 items-end lg:pl-[128px] xl:pl-[147px] 2xl:pl-[165px] 3xl:pl-[198px] w-[100%]">
            <div className="bg-gradient2  2xl:h-[1109px] 3xl:h-[1331px] lg:h-[862px] xl:h-[986px] w-[100%]"></div>
          </Column>
          <Column className="absolute right-[3%] top-[4%] w-[82%]">
            <Row className="items-center w-[100%]">
              <Img
                src="images/img_file1.png"
                className="lg:h-[49px] xl:h-[56px] 2xl:h-[63px] 3xl:h-[75px] w-[15%]"
                alt="fileOne"
              />
              <Button
                className="flex lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] items-center justify-center lg:ml-[633px] xl:ml-[724px] 2xl:ml-[815px] 3xl:ml-[977px] lg:w-[33px] xl:w-[38px] 2xl:w-[43px] 3xl:w-[51px]"
                shape="icbRoundedBorder20"
                size="mdIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_group35.png"
                  className="flex items-center justify-center lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px]"
                  alt="Group104"
                />
              </Button>
              <Button
                className="flex lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] items-center justify-center 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] lg:w-[33px] xl:w-[38px] 2xl:w-[43px] 3xl:w-[51px]"
                shape="icbRoundedBorder20"
                size="mdIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_group36.png"
                  className="flex items-center justify-center lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px]"
                  alt="Group105"
                />
              </Button>
            </Row>
            <Text className="font-medium lg:mt-[31px] xl:mt-[36px] 2xl:mt-[40px] 3xl:mt-[48px] lg:text-[29px] xl:text-[33px] 2xl:text-[37px] 3xl:text-[45px] text-bluegray_900 w-[auto]">
              Personal Profile
            </Text>
            <Column className="bg-white_A700 items-center justify-center lg:mt-[24px] xl:mt-[28px] 2xl:mt-[31px] 3xl:mt-[37px] lg:p-[25px] xl:p-[28px] 2xl:p-[32px] 3xl:p-[38px] rounded-radius47 shadow-bs1 w-[100%]">
              <Row className="mt-[1px] w-[99%]">
                <Text className="font-medium lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                  Patient Information
                  <br />
                </Text>
                <Button
                  className="font-semibold lg:ml-[449px] xl:ml-[514px] 2xl:ml-[578px] 3xl:ml-[693px] 2xl:mt-[10px] 3xl:mt-[12px] lg:mt-[8px] xl:mt-[9px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[11%]"
                  shape="RoundedBorder5"
                  size="md"
                  variant="FillRed300"
                >
                  Patient List
                </Button>
                <Button
                  className="font-semibold lg:ml-[13px] xl:ml-[15px] 2xl:ml-[17px] 3xl:ml-[20px] 2xl:mt-[10px] 3xl:mt-[12px] lg:mt-[8px] xl:mt-[9px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[11%]"
                  shape="RoundedBorder5"
                  size="md"
                  variant="FillPurple300"
                >
                  Add Patient
                </Button>
              </Row>
              <Row className="items-center lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[99%]">
                <Img
                  src="images/img_rectangle49.png"
                  className="lg:h-[161px] xl:h-[185px] 2xl:h-[208px] 3xl:h-[249px] rounded-radius47 lg:w-[161px] xl:w-[184px] 2xl:w-[207px] 3xl:w-[248px]"
                  alt="RectangleFortyNine"
                />
                <Column className="bg-white_A700 xl:ml-[11px] 2xl:ml-[12px] 3xl:ml-[15px] lg:ml-[9px] lg:p-[18px] xl:p-[21px] 2xl:p-[24px] 3xl:p-[29px] rounded-radius47 shadow-bs1 w-[78%]">
                  <Text className="font-medium 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] xl:mt-[4px] lg:mt-[4px] 2xl:mt-[5px] 3xl:mt-[6px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                    About Patient
                  </Text>
                  <Text className="font-light leading-[normal] xl:ml-[10px] 2xl:ml-[11px] 3xl:ml-[14px] lg:ml-[9px] lg:mt-[10px] xl:mt-[12px] 2xl:mt-[13px] 3xl:mt-[16px] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[96%]">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen book.
                  </Text>
                  <Row className="items-center 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] mr-[auto] lg:mt-[23px] xl:mt-[26px] 2xl:mt-[29px] 3xl:mt-[35px] w-[61%]">
                    <Text className="font-medium lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                      Email
                    </Text>
                    <Text className="font-medium lg:ml-[135px] xl:ml-[155px] 2xl:ml-[174px] 3xl:ml-[209px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                      Phone Number
                    </Text>
                    <Text className="font-medium lg:ml-[55px] xl:ml-[63px] 2xl:ml-[71px] 3xl:ml-[85px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                      Address
                    </Text>
                  </Row>
                  <Row className="justify-between xl:ml-[10px] 2xl:ml-[11px] 3xl:ml-[14px] lg:ml-[9px] 3xl:mt-[11px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] w-[96%]">
                    <Text className="font-light mt-[1px] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      johnsmith@gmail.com
                    </Text>
                    <Text className="font-light mb-[1px] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      +91 8548521524
                    </Text>
                    <Text className="font-light mt-[1px] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      345, Sarju Appt., Mota Varacha, Surat Gujarat, India.
                    </Text>
                  </Row>
                </Column>
              </Row>
              <Row className="items-center 3xl:mb-[10px] lg:mb-[7px] xl:mb-[8px] 2xl:mb-[9px] lg:mt-[17px] xl:mt-[20px] 2xl:mt-[22px] 3xl:mt-[27px] w-[100%]">
                <Column className="bg-white_A700 lg:p-[22px] xl:p-[25px] 2xl:p-[28px] 3xl:p-[34px] rounded-radius47 shadow-bs1 w-[56%]">
                  <Text className="font-medium ml-[1px] 2xl:mt-[10px] 3xl:mt-[12px] lg:mt-[8px] xl:mt-[9px] lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                    Past Visit History
                  </Text>
                  <Button
                    className="font-light lg:mt-[16px] xl:mt-[19px] 2xl:mt-[21px] 3xl:mt-[25px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[99%]"
                    size="xl"
                    variant="FillBlue50"
                  >
                    Date Doctor Treatment Charges Actions
                  </Button>
                  <List
                    className="gap-[0] mb-[4px] min-h-[auto] lg:ml-[23px] xl:ml-[26px] 2xl:ml-[29px] 3xl:ml-[35px] lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[94%]"
                    orientation="vertical"
                  >
                    <Row className="items-center lg:my-[12px] xl:my-[14px] 2xl:my-[16px] 3xl:my-[19px] w-[100%]">
                      <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] w-[74%]">
                        <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] right-[17%] w-[22%]"></div>
                        <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                          <span className="text-bluegray_900 font-kanit">
                            12 Jan 2022{" "}
                          </span>
                          <span className="text-bluegray_500 font-kanit font-medium">
                            Dr.Jacob Ryan
                          </span>
                          <span className="text-bluegray_900 font-kanit">
                            {" "}
                          </span>
                          <span className="text-red_50 font-kanit">
                            Check up{" "}
                          </span>
                          <span className="text-bluegray_900 font-kanit">
                            $145{" "}
                          </span>
                        </Text>
                      </Stack>
                      <Button
                        className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[38px] xl:ml-[44px] 2xl:ml-[49px] 3xl:ml-[59px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                        shape="icbRoundedBorder8"
                      >
                        <Img
                          src="images/img_group49.png"
                          className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                          alt="Group114"
                        />
                      </Button>
                      <Button
                        className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[14px] xl:ml-[16px] 2xl:ml-[18px] 3xl:ml-[21px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                        shape="icbRoundedBorder8"
                      >
                        <Img
                          src="images/img_group48.png"
                          className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                          alt="Group113"
                        />
                      </Button>
                    </Row>
                    <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                    <Row className="items-center lg:my-[12px] xl:my-[14px] 2xl:my-[16px] 3xl:my-[19px] w-[100%]">
                      <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] w-[59%]">
                        <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] right-[0] w-[24%]"></div>
                        <Text className="absolute bottom-[13%] font-normal left-[0] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                          <span className="text-bluegray_900 font-kanit">
                            12 Jan 2022{" "}
                          </span>
                          <span className="text-bluegray_500 font-kanit font-medium">
                            Dr.Jacob Ryan
                          </span>
                          <span className="text-bluegray_900 font-kanit">
                            {" "}
                          </span>
                          <span className="text-red_50 font-kanit">X-Ray </span>
                          <span className="text-bluegray_900 font-kanit">
                            {" "}
                          </span>
                        </Text>
                      </Stack>
                      <Text className="font-normal lg:ml-[37px] xl:ml-[42px] 2xl:ml-[47px] 3xl:ml-[57px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                        $52
                      </Text>
                      <Button
                        className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[39px] xl:ml-[45px] 2xl:ml-[51px] 3xl:ml-[61px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                        shape="icbRoundedBorder8"
                      >
                        <Img
                          src="images/img_group49.png"
                          className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                          alt="Group112"
                        />
                      </Button>
                      <Button
                        className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[14px] xl:ml-[16px] 2xl:ml-[18px] 3xl:ml-[21px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                        shape="icbRoundedBorder8"
                      >
                        <Img
                          src="images/img_group48.png"
                          className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                          alt="Group111"
                        />
                      </Button>
                    </Row>
                    <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                    <Row className="justify-between lg:my-[12px] xl:my-[14px] 2xl:my-[16px] 3xl:my-[19px] w-[100%]">
                      <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[62%]">
                        <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] right-[0] w-[27%]"></div>
                        <Text className="absolute bottom-[13%] font-normal inset-x-[0] mx-[auto] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[max-content]">
                          <span className="text-bluegray_900 font-kanit">
                            12 Jan 2022{" "}
                          </span>
                          <span className="text-bluegray_500 font-kanit font-medium">
                            {" "}
                            Dr.Jacob Ryan
                          </span>
                          <span className="text-bluegray_900 font-kanit">
                            {" "}
                          </span>
                          <span className="text-red_50 font-kanit">
                            Blood Test{" "}
                          </span>
                          <span className="text-bluegray_900 font-kanit">
                            {" "}
                          </span>
                        </Text>
                      </Stack>
                      <Text className="font-normal 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                        $52
                      </Text>
                      <Button
                        className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                        shape="icbRoundedBorder8"
                      >
                        <Img
                          src="images/img_group49.png"
                          className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                          alt="Group110"
                        />
                      </Button>
                      <Button
                        className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                        shape="icbRoundedBorder8"
                      >
                        <Img
                          src="images/img_group48.png"
                          className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                          alt="Group109"
                        />
                      </Button>
                    </Row>
                  </List>
                </Column>
                <Column className="bg-white_A700 lg:ml-[17px] xl:ml-[20px] 2xl:ml-[22px] 3xl:ml-[27px] lg:p-[19px] xl:p-[22px] 2xl:p-[25px] 3xl:p-[30px] rounded-radius47 shadow-bs1 w-[42%]">
                  <Text className="font-medium lg:ml-[3px] 2xl:ml-[4px] xl:ml-[4px] 3xl:ml-[5px] lg:mt-[11px] xl:mt-[12px] 2xl:mt-[14px] 3xl:mt-[17px] lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                    General Report
                    <br />
                  </Text>
                  <Row className="justify-between lg:ml-[3px] 2xl:ml-[4px] xl:ml-[4px] 3xl:ml-[5px] lg:mt-[15px] xl:mt-[17px] 2xl:mt-[19px] 3xl:mt-[23px] w-[97%]">
                    <Text className="font-medium lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                      Average Heart Beat
                    </Text>
                    <Text className="font-normal mt-[1px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      93
                    </Text>
                  </Row>
                  <div
                    className="xl:h-[10px] 2xl:h-[11px] 3xl:h-[13px] lg:h-[9px] xl:ml-[4px] lg:ml-[4px] 2xl:ml-[5px] 3xl:ml-[6px] lg:mt-[4px] xl:mt-[5px] 2xl:mt-[6px] 3xl:mt-[7px] overflow-hidden relative w-[97%]"
                    name="Group123"
                  >
                    <div className="w-full h-full absolute bg-indigo_50"></div>
                    <div
                      className="h-full absolute bg-purple_300"
                      style={{ width: "73%" }}
                    ></div>
                  </div>
                  <Row className="justify-between lg:ml-[3px] 2xl:ml-[4px] xl:ml-[4px] 3xl:ml-[5px] lg:mt-[17px] xl:mt-[20px] 2xl:mt-[22px] 3xl:mt-[27px] w-[97%]">
                    <Text className="font-medium lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                      Normal Blood Pressure
                    </Text>
                    <Text className="font-normal mt-[1px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      89
                    </Text>
                  </Row>
                  <div
                    className="xl:h-[10px] 2xl:h-[11px] 3xl:h-[13px] lg:h-[9px] xl:ml-[4px] lg:ml-[4px] 2xl:ml-[5px] 3xl:ml-[6px] lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] overflow-hidden relative w-[97%]"
                    name="Group124"
                  >
                    <div className="w-full h-full absolute bg-indigo_50"></div>
                    <div
                      className="h-full absolute bg-teal_200"
                      style={{ width: "71%" }}
                    ></div>
                  </div>
                  <Row className="justify-between lg:ml-[3px] 2xl:ml-[4px] xl:ml-[4px] 3xl:ml-[5px] lg:mt-[19px] xl:mt-[22px] 2xl:mt-[25px] 3xl:mt-[30px] w-[97%]">
                    <Text className="font-medium lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                      Blood Sugar level{" "}
                    </Text>
                    <Text className="font-normal mt-[1px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      60
                    </Text>
                  </Row>
                  <div
                    className="xl:h-[10px] 2xl:h-[11px] 3xl:h-[13px] lg:h-[9px] xl:ml-[4px] lg:ml-[4px] 2xl:ml-[5px] 3xl:ml-[6px] lg:mt-[4px] xl:mt-[5px] 2xl:mt-[6px] 3xl:mt-[7px] overflow-hidden relative w-[97%]"
                    name="Group125"
                  >
                    <div className="w-full h-full absolute bg-indigo_50"></div>
                    <div
                      className="h-full absolute bg-blue_300"
                      style={{ width: "59%" }}
                    ></div>
                  </div>
                  <Row className="justify-between lg:ml-[3px] 2xl:ml-[4px] xl:ml-[4px] 3xl:ml-[5px] lg:mt-[18px] xl:mt-[21px] 2xl:mt-[24px] 3xl:mt-[29px] w-[97%]">
                    <Text className="font-medium lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                      Haemoglobin
                    </Text>
                    <Text className="font-normal mt-[1px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      80%
                    </Text>
                  </Row>
                  <div
                    className="xl:h-[10px] 2xl:h-[11px] 3xl:h-[13px] lg:h-[9px] xl:ml-[4px] lg:ml-[4px] 2xl:ml-[5px] 3xl:ml-[6px] lg:mt-[4px] xl:mt-[5px] 2xl:mt-[6px] 3xl:mt-[7px] overflow-hidden relative w-[97%]"
                    name="Group126"
                  >
                    <div className="w-full h-full absolute bg-indigo_50"></div>
                    <div
                      className="h-full absolute bg-red_300"
                      style={{ width: "67%" }}
                    ></div>
                  </div>
                </Column>
              </Row>
            </Column>
          </Column>
        </Stack>
        <Column className="absolute left-[4%] top-[8%] w-[13%]">
          <Row className="lg:ml-[5px] xl:ml-[6px] 2xl:ml-[7px] 3xl:ml-[8px] w-[61%]">
            <Stack className="bg-white_A700 lg:h-[49px] xl:h-[57px] 2xl:h-[64px] 3xl:h-[76px] px-[3px] rounded-radius50 shadow-bs5 lg:w-[49px] xl:w-[56px] 2xl:w-[63px] 3xl:w-[75px]">
              <Img
                src="images/img_man1.png"
                className="absolute bottom-[0] lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] inset-x-[0] mx-[auto] lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
                alt="manOne"
              />
            </Stack>
            <Button
              className="flex lg:h-[23px] xl:h-[26px] 2xl:h-[29px] 3xl:h-[35px] items-center justify-center lg:ml-[18px] xl:ml-[20px] 2xl:ml-[23px] 3xl:ml-[28px] lg:mt-[6px] xl:mt-[7px] 2xl:mt-[8px] 3xl:mt-[9px] lg:w-[22px] xl:w-[25px] 2xl:w-[28px] 3xl:w-[34px]"
              shape="icbRoundedBorder8"
              variant="icbOutlineDeeppurple100a31_2"
            >
              <Img
                src="images/img_group53.png"
                className="flex items-center justify-center lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px]"
                alt="Group119"
              />
            </Button>
          </Row>
          <Text className="font-normal lg:leading-[16px] xl:leading-[19px] 2xl:leading-[21px] 3xl:leading-[25px] lg:mt-[4px] xl:mt-[5px] 2xl:mt-[6px] 3xl:mt-[7px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 text-center w-[40%]">
            <span className="text-bluegray_900 font-kanit lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px]">
              Sarah Smith
              <br />
              <br />
            </span>
            <span className="text-bluegray_900 font-kanit uppercase font-medium lg:text-[9px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px]">
              Admin
            </span>
          </Text>
          <Column className="items-center lg:ml-[10px] xl:ml-[12px] 2xl:ml-[13px] 3xl:ml-[16px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[64px] w-[93%]">
            <Button
              className="flex lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] items-center justify-center lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
              shape="icbRoundedBorder20"
              size="lgIcn"
              variant="icbOutlineDeeppurple100a3"
            >
              <Img
                src="images/img_volume.svg"
                className="flex items-center justify-center lg:h-[24px] xl:h-[27px] 2xl:h-[30px] 3xl:h-[36px]"
                alt="volume"
              />
            </Button>
            <Row className="bg-gray_401 items-center justify-end lg:mt-[18px] xl:mt-[20px] 2xl:mt-[23px] 3xl:mt-[28px] lg:p-[11px] xl:p-[13px] 2xl:p-[15px] 3xl:p-[18px] rounded-radius20 shadow-bs1 w-[91%]">
              <Img
                src="images/img_appointment1.png"
                className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] my-[2px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                alt="appointmentOne"
              />
              <Text className="font-normal 3xl:ml-[10px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                Appointment
              </Text>
            </Row>
            <Img
              src="images/img_settinglines1.png"
              className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] 3xl:mt-[105px] lg:mt-[68px] xl:mt-[78px] 2xl:mt-[88px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
              alt="settinglinesOne"
            />
            <Img
              src="images/img_team1.png"
              className="lg:h-[19px] xl:h-[22px] 2xl:h-[25px] 3xl:h-[30px] lg:mt-[31px] xl:mt-[36px] 2xl:mt-[40px] 3xl:mt-[48px] lg:w-[18px] xl:w-[21px] 2xl:w-[24px] 3xl:w-[29px]"
              alt="teamOne"
            />
            <Img
              src="images/img_securitypaymen.png"
              className="lg:h-[21px] xl:h-[24px] 2xl:h-[27px] 3xl:h-[32px] lg:mt-[26px] xl:mt-[30px] 2xl:mt-[34px] 3xl:mt-[41px] lg:w-[20px] xl:w-[23px] 2xl:w-[26px] 3xl:w-[31px]"
              alt="securitypaymen"
            />
            <Row className="bg-bluegray_100 justify-end lg:mt-[60px] xl:mt-[69px] 2xl:mt-[78px] 3xl:mt-[94px] xl:p-[11px] 2xl:p-[12px] 3xl:p-[15px] lg:p-[9px] rounded-radius20 shadow-bs1 w-[100%]">
              <Img
                src="images/img_appointment1.png"
                className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] lg:mb-[6px] xl:mb-[7px] 2xl:mb-[8px] 3xl:mb-[9px] mt-[1px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                alt="appointmentTwo"
              />
              <Text className="font-normal ml-[4px] lg:mt-[3px] 2xl:mt-[4px] xl:mt-[4px] 3xl:mt-[5px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                Medical Records
              </Text>
            </Row>
            <Img
              src="images/img_power2.png"
              className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] lg:mt-[151px] xl:mt-[172px] 2xl:mt-[194px] 3xl:mt-[233px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
              alt="powerTwo"
            />
          </Column>
        </Column>
      </Stack>
    </>
  );
};

export default UserPage;
