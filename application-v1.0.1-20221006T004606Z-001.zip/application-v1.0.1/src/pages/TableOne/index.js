import React from "react";

import { Stack, Column, Text, Img, Row } from "components";

const TableOnePage = () => {
  return (
    <>
      <Stack className="font-lato lg:h-[414px] xl:h-[474px] 2xl:h-[533px] 3xl:h-[639px] mx-[auto] w-[100%]">
        <Column className="absolute bg-white_A700 justify-end xl:py-[6px] lg:py-[6px] 2xl:py-[7px] 3xl:py-[9px] rounded-radius8 shadow-bs6 w-[100%]">
          <Text className="font-bold lg:ml-[24px] xl:ml-[27px] 2xl:ml-[31px] 3xl:ml-[37px] xl:mr-[1023px] 2xl:mr-[1151px] 3xl:mr-[1381px] lg:mr-[894px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] lg:text-[20px] xl:text-[23px] 2xl:text-[25px] 3xl:text-[31px] text-gray_900 tracking-ls1 w-[auto]">
            Appointment Activity
          </Text>
          <Stack className="lg:h-[340px] xl:h-[388px] 2xl:h-[437px] 3xl:h-[524px] lg:mt-[17px] xl:mt-[19px] 2xl:mt-[22px] 3xl:mt-[26px] w-[100%]">
            <Column className="absolute bottom-[0] items-center justify-end w-[100%]">
              <Column className="bg-gray_200_6c lg:p-[20px] xl:p-[23px] 2xl:p-[25px] 3xl:p-[31px] w-[100%]">
                <Text className="font-bold mb-[1px] ml-[3px] lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                  Name
                </Text>
              </Column>
              <Stack className="lg:h-[283px] xl:h-[324px] 2xl:h-[364px] 3xl:h-[437px] w-[100%]">
                <Column className="absolute items-center w-[100%]">
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                  <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
                </Column>
                <Stack className="absolute bottom-[0] lg:h-[282px] xl:h-[322px] 2xl:h-[363px] 3xl:h-[435px] w-[100%]">
                  <Img
                    src="images/img_dividers_2185X1110.svg"
                    className="absolute bottom-[0] lg:h-[2205px] xl:h-[2522px] 2xl:h-[2837px] 3xl:h-[3404px] w-[100%]"
                    alt="dividers"
                  />
                  <Row className="absolute h-[max-content] inset-[0] items-center justify-center m-[auto] w-[95%]">
                    <Column className="w-[96%]">
                      <Img
                        src="images/img_circle.png"
                        className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                        alt="circle"
                      />
                      <Img
                        src="images/img_circle_32X32.png"
                        className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                        alt="circle One"
                      />
                      <Img
                        src="images/img_circle_1.png"
                        className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                        alt="circle Two"
                      />
                      <Img
                        src="images/img_circle_2.png"
                        className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                        alt="circle Three"
                      />
                      <Img
                        src="images/img_circle_3.png"
                        className="lg:h-[33px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] lg:mt-[24px] xl:mt-[27px] 2xl:mt-[31px] 3xl:mt-[37px] rounded-radius50 lg:w-[32px] xl:w-[36px] 2xl:w-[41px] 3xl:w-[49px]"
                        alt="circle Four"
                      />
                    </Column>
                    <Column className="items-center w-[1%]">
                      <Img
                        src="images/img_edit.svg"
                        className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] w-[100%]"
                        alt="edit"
                      />
                      <Img
                        src="images/img_edit.svg"
                        className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                        alt="edit One"
                      />
                      <Img
                        src="images/img_edit.svg"
                        className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                        alt="edit Two"
                      />
                      <Img
                        src="images/img_edit.svg"
                        className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                        alt="edit Three"
                      />
                      <Img
                        src="images/img_edit.svg"
                        className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] w-[100%]"
                        alt="edit Four"
                      />
                    </Column>
                    <Column className="items-center lg:ml-[16px] xl:ml-[18px] 2xl:ml-[20px] 3xl:ml-[24px] w-[1%]">
                      <Img
                        src="images/img_trash.svg"
                        className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] w-[100%]"
                        alt="trash"
                      />
                      <Img
                        src="images/img_trash.svg"
                        className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                        alt="trash One"
                      />
                      <Img
                        src="images/img_trash.svg"
                        className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                        alt="trash Two"
                      />
                      <Img
                        src="images/img_trash.svg"
                        className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                        alt="trash Three"
                      />
                      <Img
                        src="images/img_trash.svg"
                        className="lg:h-[15px] xl:h-[17px] 2xl:h-[19px] 3xl:h-[22px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] w-[100%]"
                        alt="trash Four"
                      />
                    </Column>
                  </Row>
                </Stack>
              </Stack>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
              <div className="bg-white_A700 lg:h-[57px] xl:h-[65px] 2xl:h-[73px] 3xl:h-[88px] w-[100%]"></div>
            </Column>
            <Column className="absolute bottom-[0] justify-end left-[25%] w-[17%]">
              <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                Email
              </Text>
              <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                lesie.alexander@example.com
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                ronald.richards@example.com
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                jane.cooper@example.com
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                robert.fox@gmail.com
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                jenny.wilson@example.com
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
            </Column>
            <Column className="absolute bottom-[0] inset-x-[0] justify-end mx-[auto] w-[9%]">
              <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                Date
              </Text>
              <Text className="font-normal lg:mt-[41px] xl:mt-[47px] 2xl:mt-[53px] 3xl:mt-[63px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                10/10/2020
              </Text>
              <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                10/12/2020
              </Text>
              <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                10/13/2020
              </Text>
              <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                10/14/2020
              </Text>
              <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                10/15/2020
              </Text>
              <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
            </Column>
            <Column className="absolute bottom-[0] justify-end right-[36%] w-[9%]">
              <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                Visit Time
              </Text>
              <Text className="font-normal lg:mt-[41px] xl:mt-[47px] 2xl:mt-[53px] 3xl:mt-[63px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                09:15-09:45am
              </Text>
              <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                12:00-12:45pm
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                01:15-01:45pm
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                02:00-02:45pm
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                12:00-12:45pm
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
            </Column>
            <Column className="absolute bottom-[0] justify-end right-[23%] w-[11%]">
              <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                Doctor
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Dr. Jacob Jones
              </Text>
              <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Dr. Theresa Webb
              </Text>
              <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Dr. Jacob Jones
              </Text>
              <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Dr. Arlene McCoy
              </Text>
              <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Dr. Esther Howard
              </Text>
              <Text className="font-normal lg:mt-[39px] xl:mt-[45px] 2xl:mt-[50px] 3xl:mt-[60px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
            </Column>
            <Column className="absolute bottom-[0] justify-end right-[9%] w-[12%]">
              <Text className="font-bold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-gray_900 tracking-ls1 w-[auto]">
                Conditions
              </Text>
              <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Mumps Stage II
              </Text>
              <Text className="font-normal lg:mt-[40px] xl:mt-[46px] 2xl:mt-[51px] 3xl:mt-[62px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Depression
              </Text>
              <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Arthritis
              </Text>
              <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Fracture
              </Text>
              <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Depression
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
              <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
                Large
              </Text>
            </Column>
          </Stack>
        </Column>
        <Column className="absolute bottom-[0] justify-end left-[6%] w-[16%]">
          <Text className="font-normal not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Leslie Alexander
          </Text>
          <Text className="font-normal lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Ronald Richards
          </Text>
          <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Jane Cooper
          </Text>
          <Text className="font-normal lg:mt-[38px] xl:mt-[43px] 2xl:mt-[49px] 3xl:mt-[59px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Robert Fox
          </Text>
          <Text className="font-normal lg:mt-[43px] xl:mt-[49px] 2xl:mt-[55px] 3xl:mt-[66px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Jenny Wilson
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
          <Text className="font-normal lg:mt-[36px] xl:mt-[41px] 2xl:mt-[46px] 3xl:mt-[56px] not-italic lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_700 tracking-ls1 w-[auto]">
            Large
          </Text>
        </Column>
      </Stack>
    </>
  );
};

export default TableOnePage;
