import React from "react";

import { Stack, Column, Row, Img, Button, Text, List, Line } from "components";

const DataGridTablePage = () => {
  return (
    <>
      <Stack className="bg-gradient  font-kanit xl:h-[1125px] 2xl:h-[1266px] 3xl:h-[1519px] lg:h-[984px] mx-[auto] lg:px-[41px] xl:px-[47px] 2xl:px-[53px] 3xl:px-[63px] w-[100%]">
        <Stack className="absolute 2xl:h-[1109px] 3xl:h-[1331px] lg:h-[862px] xl:h-[986px] inset-[0] justify-center m-[auto] w-[92%]">
          <Column className="absolute bg-white_A700_90 items-end lg:pl-[128px] xl:pl-[147px] 2xl:pl-[165px] 3xl:pl-[198px] w-[100%]">
            <div className="bg-gradient2  2xl:h-[1109px] 3xl:h-[1331px] lg:h-[862px] xl:h-[986px] w-[100%]"></div>
          </Column>
          <Column className="absolute right-[4%] top-[4%] w-[81%]">
            <Row className="items-center lg:ml-[3px] 2xl:ml-[4px] xl:ml-[4px] 3xl:ml-[5px] w-[95%]">
              <Img
                src="images/img_file1.png"
                className="lg:h-[49px] xl:h-[56px] 2xl:h-[63px] 3xl:h-[75px] w-[16%]"
                alt="fileOne"
              />
              <Button
                className="font-bold lg:ml-[319px] xl:ml-[365px] 2xl:ml-[411px] 3xl:ml-[493px] lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-center w-[19%]"
                shape="RoundedBorder20"
                size="xl"
                variant="OutlineDeeppurple100a3"
              >
                Delete Files
              </Button>
              <Button
                className="font-bold lg:ml-[12px] xl:ml-[14px] 2xl:ml-[16px] 3xl:ml-[19px] lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-center w-[17%]"
                shape="RoundedBorder20"
                size="xl"
                variant="OutlineDeeppurple100a3"
              >
                Upload Files
              </Button>
              <Button
                className="flex lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] items-center justify-center xl:ml-[11px] 2xl:ml-[12px] 3xl:ml-[15px] lg:ml-[9px] lg:w-[33px] xl:w-[38px] 2xl:w-[43px] 3xl:w-[51px]"
                shape="icbRoundedBorder20"
                size="mdIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_group35.png"
                  className="flex items-center justify-center lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px]"
                  alt="GroupEightySeven"
                />
              </Button>
            </Row>
            <Text className="font-medium lg:mt-[35px] xl:mt-[40px] 2xl:mt-[45px] 3xl:mt-[54px] lg:text-[29px] xl:text-[33px] 2xl:text-[37px] 3xl:text-[45px] text-bluegray_900 w-[auto]">
              Medical Records Uploaded
              <br />
            </Text>
            <Column className="bg-white_A700 items-center lg:ml-[29px] xl:ml-[33px] 2xl:ml-[37px] 3xl:ml-[45px] lg:mt-[21px] xl:mt-[24px] 2xl:mt-[27px] 3xl:mt-[33px] lg:p-[22px] xl:p-[25px] 2xl:p-[28px] 3xl:p-[34px] rounded-radius47 shadow-bs1 w-[96%]">
              <Row className="mt-[3px] w-[98%]">
                <Text className="font-medium lg:mt-[4px] xl:mt-[5px] 2xl:mt-[6px] 3xl:mt-[7px] lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                  All Records
                  <br />
                </Text>
                <Text className="font-light lg:ml-[391px] xl:ml-[447px] 2xl:ml-[503px] 3xl:ml-[604px] lg:mt-[11px] xl:mt-[12px] 2xl:mt-[14px] 3xl:mt-[17px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900_cc w-[auto]">
                  Search By
                </Text>
                <Row className="bg-white_A700 items-center justify-between 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] 3xl:p-[11px] lg:p-[7px] xl:p-[8px] 2xl:p-[9px] rounded-radius8 shadow-bs2 w-[25%]">
                  <Text className="font-light lg:ml-[3px] 2xl:ml-[4px] xl:ml-[4px] 3xl:ml-[5px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                    Name
                  </Text>
                  <Img
                    src="images/img_downarrow1.png"
                    className="lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] mb-[1px] lg:mt-[3px] 2xl:mt-[4px] xl:mt-[4px] 3xl:mt-[5px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    alt="downarrowTwo"
                  />
                </Row>
                <Button
                  className="flex lg:h-[26px] xl:h-[29px] 2xl:h-[33px] 3xl:h-[39px] items-center justify-center lg:ml-[10px] xl:ml-[12px] 2xl:ml-[13px] 3xl:ml-[16px] mt-[3px] lg:w-[25px] xl:w-[28px] 2xl:w-[32px] 3xl:w-[38px]"
                  shape="icbRoundedBorder8"
                  variant="icbOutlineDeeppurple200a31_2"
                >
                  <Img
                    src="images/img_group100.png"
                    className="flex items-center justify-center lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px]"
                    alt="Group100"
                  />
                </Button>
              </Row>
              <Text className="bg-blue_50 font-light xl:mt-[11px] 2xl:mt-[12px] 3xl:mt-[15px] lg:mt-[9px] 3xl:pb-[10px] lg:pb-[7px] xl:pb-[8px] 2xl:pb-[9px] lg:pl-[24px] xl:pl-[28px] 2xl:pl-[31px] 3xl:pl-[37px] lg:pt-[11px] xl:pt-[12px] 2xl:pt-[14px] 3xl:pt-[17px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900_ab w-[1084px]">
                Date Doctor Treatment Importance Date Uploaded File Size Next
                Checked Actions
              </Text>
              <List
                className="gap-[0] min-h-[auto] lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[96%]"
                orientation="vertical"
              >
                <Row className="justify-between lg:my-[14px] xl:my-[16px] 2xl:my-[18px] 3xl:my-[21px] w-[100%]">
                  <Button
                    className="flex lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] items-center justify-center lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    shape="icbRoundedBorder4"
                    variant="icbOutlineIndigo50"
                  >
                    <Img
                      src="images/img_checkmark.svg"
                      className="flex items-center justify-center"
                      alt="checkmark"
                    />
                  </Button>
                  <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[82%]">
                    <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] left-[28%] w-[10%]"></div>
                    <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                      <span className="text-bluegray_900 font-kanit">
                        12 Jan 2022{" "}
                      </span>
                      <span className="text-bluegray_500 font-kanit font-medium">
                        Dr.Jacob Ryan
                      </span>
                      <span className="text-bluegray_900 font-kanit"> </span>
                      <span className="text-red_50 font-kanit">Check up </span>
                      <span className="text-bluegray_900 font-kanit">
                        $145 5% 8% $156{" "}
                      </span>
                    </Text>
                  </Stack>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group49.png"
                      className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                      alt="GroupNinetyOne"
                    />
                  </Button>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group48.png"
                      className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                      alt="GroupNinety"
                    />
                  </Button>
                </Row>
                <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                <Row className="justify-between lg:my-[14px] xl:my-[16px] 2xl:my-[18px] 3xl:my-[21px] w-[100%]">
                  <Button
                    className="flex lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] items-center justify-center lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    shape="icbRoundedBorder4"
                    variant="icbOutlineIndigo50"
                  >
                    <Img
                      src="images/img_checkmark.svg"
                      className="flex items-center justify-center"
                      alt="checkmark One"
                    />
                  </Button>
                  <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[82%]">
                    <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] left-[28%] w-[10%]"></div>
                    <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                      <span className="text-bluegray_900 font-kanit">
                        12 Jan 2022{" "}
                      </span>
                      <span className="text-bluegray_500 font-kanit font-medium">
                        Dr.Jacob Ryan
                      </span>
                      <span className="text-bluegray_900 font-kanit"> </span>
                      <span className="text-red_50 font-kanit">Check up </span>
                      <span className="text-bluegray_900 font-kanit">
                        $145 5% 8% $156{" "}
                      </span>
                    </Text>
                  </Stack>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group49.png"
                      className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                      alt="GroupEightySix"
                    />
                  </Button>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group48.png"
                      className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                      alt="GroupEightyFour"
                    />
                  </Button>
                </Row>
                <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                <Row className="justify-between lg:my-[14px] xl:my-[16px] 2xl:my-[18px] 3xl:my-[21px] w-[100%]">
                  <Button
                    className="flex lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] items-center justify-center lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    shape="icbRoundedBorder4"
                    variant="icbOutlineIndigo50"
                  >
                    <Img
                      src="images/img_checkmark.svg"
                      className="flex items-center justify-center"
                      alt="checkmark Two"
                    />
                  </Button>
                  <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[82%]">
                    <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] left-[28%] w-[10%]"></div>
                    <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                      <span className="text-bluegray_900 font-kanit">
                        12 Jan 2022{" "}
                      </span>
                      <span className="text-bluegray_500 font-kanit font-medium">
                        Dr.Jacob Ryan
                      </span>
                      <span className="text-bluegray_900 font-kanit"> </span>
                      <span className="text-red_50 font-kanit">Check up </span>
                      <span className="text-bluegray_900 font-kanit">
                        $145 5% 8% $156{" "}
                      </span>
                    </Text>
                  </Stack>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group49.png"
                      className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                      alt="GroupEightyThree"
                    />
                  </Button>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group48.png"
                      className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                      alt="GroupEightyOne"
                    />
                  </Button>
                </Row>
                <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                <Row className="justify-between lg:my-[14px] xl:my-[16px] 2xl:my-[18px] 3xl:my-[21px] w-[100%]">
                  <Button
                    className="flex lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] items-center justify-center lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    shape="icbRoundedBorder4"
                    variant="icbOutlineIndigo50"
                  >
                    <Img
                      src="images/img_checkmark.svg"
                      className="flex items-center justify-center"
                      alt="checkmark Three"
                    />
                  </Button>
                  <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[82%]">
                    <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] left-[28%] w-[10%]"></div>
                    <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                      <span className="text-bluegray_900 font-kanit">
                        12 Jan 2022{" "}
                      </span>
                      <span className="text-bluegray_500 font-kanit font-medium">
                        Dr.Jacob Ryan
                      </span>
                      <span className="text-bluegray_900 font-kanit"> </span>
                      <span className="text-red_50 font-kanit">Check up </span>
                      <span className="text-bluegray_900 font-kanit">
                        $145 5% 8% $156{" "}
                      </span>
                    </Text>
                  </Stack>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group49.png"
                      className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                      alt="GroupEighty"
                    />
                  </Button>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group48.png"
                      className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                      alt="GroupSeventyEight"
                    />
                  </Button>
                </Row>
                <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                <Row className="justify-between lg:my-[14px] xl:my-[16px] 2xl:my-[18px] 3xl:my-[21px] w-[100%]">
                  <Button
                    className="flex lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] items-center justify-center lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    shape="icbRoundedBorder4"
                    variant="icbOutlineIndigo50"
                  >
                    <Img
                      src="images/img_checkmark.svg"
                      className="flex items-center justify-center"
                      alt="checkmark Four"
                    />
                  </Button>
                  <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[82%]">
                    <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] left-[28%] w-[10%]"></div>
                    <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                      <span className="text-bluegray_900 font-kanit">
                        12 Jan 2022{" "}
                      </span>
                      <span className="text-bluegray_500 font-kanit font-medium">
                        Dr.Jacob Ryan
                      </span>
                      <span className="text-bluegray_900 font-kanit"> </span>
                      <span className="text-red_50 font-kanit">Check up </span>
                      <span className="text-bluegray_900 font-kanit">
                        $145 5% 8% $156{" "}
                      </span>
                    </Text>
                  </Stack>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group49.png"
                      className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                      alt="GroupSeventySeven"
                    />
                  </Button>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group48.png"
                      className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                      alt="GroupSeventyFive"
                    />
                  </Button>
                </Row>
                <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                <Row className="justify-between lg:my-[14px] xl:my-[16px] 2xl:my-[18px] 3xl:my-[21px] w-[100%]">
                  <Button
                    className="flex lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] items-center justify-center lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    shape="icbRoundedBorder4"
                    variant="icbOutlineIndigo50"
                  >
                    <Img
                      src="images/img_checkmark.svg"
                      className="flex items-center justify-center"
                      alt="checkmark Five"
                    />
                  </Button>
                  <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[82%]">
                    <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] left-[28%] w-[10%]"></div>
                    <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                      <span className="text-bluegray_900 font-kanit">
                        12 Jan 2022{" "}
                      </span>
                      <span className="text-bluegray_500 font-kanit font-medium">
                        Dr.Jacob Ryan
                      </span>
                      <span className="text-bluegray_900 font-kanit"> </span>
                      <span className="text-red_50 font-kanit">Check up </span>
                      <span className="text-bluegray_900 font-kanit">
                        $145 5% 8% $156{" "}
                      </span>
                    </Text>
                  </Stack>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group49.png"
                      className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                      alt="GroupSeventyFour"
                    />
                  </Button>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group48.png"
                      className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                      alt="GroupSeventyTwo"
                    />
                  </Button>
                </Row>
                <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                <Row className="justify-between lg:my-[14px] xl:my-[16px] 2xl:my-[18px] 3xl:my-[21px] w-[100%]">
                  <Button
                    className="flex lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] items-center justify-center lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    shape="icbRoundedBorder4"
                    variant="icbOutlineIndigo50"
                  >
                    <Img
                      src="images/img_checkmark.svg"
                      className="flex items-center justify-center"
                      alt="checkmark Six"
                    />
                  </Button>
                  <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[82%]">
                    <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] left-[28%] w-[10%]"></div>
                    <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                      <span className="text-bluegray_900 font-kanit">
                        12 Jan 2022{" "}
                      </span>
                      <span className="text-bluegray_500 font-kanit font-medium">
                        Dr.Jacob Ryan
                      </span>
                      <span className="text-bluegray_900 font-kanit"> </span>
                      <span className="text-red_50 font-kanit">Check up </span>
                      <span className="text-bluegray_900 font-kanit">
                        $145 5% 8% $156{" "}
                      </span>
                    </Text>
                  </Stack>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group49.png"
                      className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                      alt="GroupSeventyOne"
                    />
                  </Button>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group48.png"
                      className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                      alt="GroupSixtyNine"
                    />
                  </Button>
                </Row>
                <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                <Row className="justify-between lg:my-[14px] xl:my-[16px] 2xl:my-[18px] 3xl:my-[21px] w-[100%]">
                  <Button
                    className="flex lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] items-center justify-center lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                    shape="icbRoundedBorder4"
                    variant="icbOutlineIndigo50"
                  >
                    <Img
                      src="images/img_checkmark.svg"
                      className="flex items-center justify-center"
                      alt="checkmark Seven"
                    />
                  </Button>
                  <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] mt-[4px] w-[82%]">
                    <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] left-[28%] w-[10%]"></div>
                    <Text className="absolute bottom-[4%] font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                      <span className="text-bluegray_900 font-kanit">
                        12 Jan 2022{" "}
                      </span>
                      <span className="text-bluegray_500 font-kanit font-medium">
                        Dr.Jacob Ryan
                      </span>
                      <span className="text-bluegray_900 font-kanit"> </span>
                      <span className="text-red_50 font-kanit">Check up </span>
                      <span className="text-bluegray_900 font-kanit">
                        $145 5% 8% $156{" "}
                      </span>
                    </Text>
                  </Stack>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group49.png"
                      className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                      alt="GroupSixtyEight"
                    />
                  </Button>
                  <Button
                    className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                    shape="icbRoundedBorder8"
                  >
                    <Img
                      src="images/img_group48.png"
                      className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                      alt="GroupSixtySix"
                    />
                  </Button>
                </Row>
              </List>
              <Row className="items-center justify-between 2xl:mb-[10px] 3xl:mb-[12px] lg:mb-[8px] xl:mb-[9px] lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[44px] w-[100%]">
                <Text className="font-light lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                  8 results found: Showing page 1 of 1<br />
                </Text>
                <Row className="bg-gray_50 border border-deep_purple_100_cc border-solid items-center 2xl:px-[10px] 3xl:px-[12px] lg:px-[8px] xl:px-[9px] w-[22%]">
                  <Text className="font-normal not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900_7f w-[auto]">
                    Previous
                  </Text>
                  <Button
                    className="font-bold lg:h-[28px] xl:h-[33px] 2xl:h-[37px] 3xl:h-[44px] 3xl:ml-[11px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center lg:w-[28px] xl:w-[32px] 2xl:w-[36px] 3xl:w-[43px]"
                    size="xl"
                    variant="OutlineDeeppurple100cc"
                  >
                    1
                  </Button>
                  <Button
                    className="font-normal lg:h-[28px] xl:h-[33px] 2xl:h-[37px] 3xl:h-[44px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center lg:w-[28px] xl:w-[32px] 2xl:w-[36px] 3xl:w-[43px]"
                    size="xl"
                    variant="OutlineDeeppurple100cc1_2"
                  >
                    2
                  </Button>
                  <Text className="font-normal lg:ml-[17px] xl:ml-[20px] 2xl:ml-[22px] 3xl:ml-[27px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900_7f w-[auto]">
                    Next
                  </Text>
                </Row>
              </Row>
            </Column>
          </Column>
        </Stack>
        <Row className="absolute inset-x-[0] mx-[auto] top-[8%] w-[86%]">
          <Column className="w-[96%]">
            <Row className="lg:ml-[5px] xl:ml-[6px] 2xl:ml-[7px] 3xl:ml-[8px] w-[10%]">
              <Stack className="bg-white_A700 lg:h-[49px] xl:h-[57px] 2xl:h-[64px] 3xl:h-[76px] px-[3px] rounded-radius50 shadow-bs5 lg:w-[49px] xl:w-[56px] 2xl:w-[63px] 3xl:w-[75px]">
                <Img
                  src="images/img_man1.png"
                  className="absolute bottom-[0] lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] inset-x-[0] mx-[auto] lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
                  alt="manOne"
                />
              </Stack>
              <Button
                className="flex lg:h-[23px] xl:h-[26px] 2xl:h-[29px] 3xl:h-[35px] items-center justify-center lg:ml-[18px] xl:ml-[20px] 2xl:ml-[23px] 3xl:ml-[28px] lg:mt-[6px] xl:mt-[7px] 2xl:mt-[8px] 3xl:mt-[9px] lg:w-[22px] xl:w-[25px] 2xl:w-[28px] 3xl:w-[34px]"
                shape="icbRoundedBorder8"
                variant="icbOutlineDeeppurple100a31_2"
              >
                <Img
                  src="images/img_group53.png"
                  className="flex items-center justify-center lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px]"
                  alt="GroupNinetyFour"
                />
              </Button>
            </Row>
            <Text className="font-normal lg:leading-[16px] xl:leading-[19px] 2xl:leading-[21px] 3xl:leading-[25px] lg:mt-[4px] xl:mt-[5px] 2xl:mt-[6px] 3xl:mt-[7px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 text-center w-[6%]">
              <span className="text-bluegray_900 font-kanit lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px]">
                Sarah Smith
                <br />
                <br />
              </span>
              <span className="text-bluegray_900 font-kanit uppercase font-medium lg:text-[9px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px]">
                Admin
              </span>
            </Text>
            <Column className="items-center lg:ml-[10px] xl:ml-[12px] 2xl:ml-[13px] 3xl:ml-[16px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[64px] w-[15%]">
              <Button
                className="flex lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] items-center justify-center lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
                shape="icbRoundedBorder20"
                size="lgIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_volume.svg"
                  className="flex items-center justify-center lg:h-[24px] xl:h-[27px] 2xl:h-[30px] 3xl:h-[36px]"
                  alt="volume"
                />
              </Button>
              <Row className="bg-gray_401 items-center justify-end lg:mt-[18px] xl:mt-[20px] 2xl:mt-[23px] 3xl:mt-[28px] lg:p-[11px] xl:p-[13px] 2xl:p-[15px] 3xl:p-[18px] rounded-radius20 shadow-bs1 w-[91%]">
                <Img
                  src="images/img_appointment1.png"
                  className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] my-[2px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                  alt="appointmentOne"
                />
                <Text className="font-normal 3xl:ml-[10px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                  Appointment
                </Text>
              </Row>
              <Img
                src="images/img_settinglines1.png"
                className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] 3xl:mt-[105px] lg:mt-[68px] xl:mt-[78px] 2xl:mt-[88px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                alt="settinglinesOne"
              />
              <Img
                src="images/img_team1.png"
                className="lg:h-[19px] xl:h-[22px] 2xl:h-[25px] 3xl:h-[30px] lg:mt-[31px] xl:mt-[36px] 2xl:mt-[40px] 3xl:mt-[48px] lg:w-[18px] xl:w-[21px] 2xl:w-[24px] 3xl:w-[29px]"
                alt="teamOne"
              />
              <Img
                src="images/img_securitypaymen.png"
                className="lg:h-[21px] xl:h-[24px] 2xl:h-[27px] 3xl:h-[32px] lg:mt-[26px] xl:mt-[30px] 2xl:mt-[34px] 3xl:mt-[41px] lg:w-[20px] xl:w-[23px] 2xl:w-[26px] 3xl:w-[31px]"
                alt="securitypaymen"
              />
              <Row className="bg-bluegray_100 justify-end lg:mt-[60px] xl:mt-[69px] 2xl:mt-[78px] 3xl:mt-[94px] xl:p-[11px] 2xl:p-[12px] 3xl:p-[15px] lg:p-[9px] rounded-radius20 shadow-bs1 w-[100%]">
                <Img
                  src="images/img_appointment1.png"
                  className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] lg:mb-[6px] xl:mb-[7px] 2xl:mb-[8px] 3xl:mb-[9px] mt-[1px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                  alt="appointmentTwo"
                />
                <Text className="font-normal ml-[4px] lg:mt-[3px] 2xl:mt-[4px] xl:mt-[4px] 3xl:mt-[5px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                  Medical Records
                </Text>
              </Row>
              <Img
                src="images/img_power2.png"
                className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] lg:mt-[151px] xl:mt-[172px] 2xl:mt-[194px] 3xl:mt-[233px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                alt="powerTwo"
              />
            </Column>
          </Column>
          <Button
            className="flex lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] items-center justify-center mt-[1px] lg:w-[33px] xl:w-[38px] 2xl:w-[43px] 3xl:w-[51px]"
            shape="icbRoundedBorder20"
            size="mdIcn"
            variant="icbOutlineDeeppurple100a3"
          >
            <Img
              src="images/img_group36.png"
              className="flex items-center justify-center lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px]"
              alt="GroupEightyEight"
            />
          </Button>
        </Row>
      </Stack>
    </>
  );
};

export default DataGridTablePage;
