import React from "react";

import { useNavigate } from "react-router-dom";
import {
  Stack,
  Img,
  Column,
  Row,
  Text,
  Button,
  Line,
  List,
  Input,
} from "components";

const DashboardPage = () => {
  const navigate = useNavigate();

  function handleNavigate1() {
    navigate("/user");
  }

  return (
    <>
      <Stack className="bg-gradient  font-kanit xl:h-[1125px] 2xl:h-[1266px] 3xl:h-[1519px] lg:h-[984px] mx-[auto] lg:px-[41px] xl:px-[47px] 2xl:px-[53px] 3xl:px-[63px] w-[100%]">
        <Stack className="absolute 2xl:h-[1109px] 3xl:h-[1331px] lg:h-[862px] xl:h-[986px] inset-[0] justify-center m-[auto] w-[92%]">
          <Img
            src="images/img_backgrounds.png"
            className="absolute 2xl:h-[1109px] 3xl:h-[1331px] lg:h-[862px] xl:h-[986px] w-[100%]"
            alt="Backgrounds"
          />
          <Column className="absolute h-[max-content] inset-y-[0] my-[auto] right-[2%] w-[83%]">
            <Row className="lg:ml-[3px] 2xl:ml-[4px] xl:ml-[4px] 3xl:ml-[5px] w-[99%]">
              <Img
                src="images/img_file1.png"
                className="lg:h-[49px] xl:h-[56px] 2xl:h-[63px] 3xl:h-[75px] lg:mt-[3px] 2xl:mt-[4px] xl:mt-[4px] 3xl:mt-[5px] w-[15%]"
                alt="fileOne"
              />
              <Row className="bg-white_A700 items-center justify-center lg:ml-[38px] xl:ml-[44px] 2xl:ml-[49px] 3xl:ml-[59px] lg:p-[11px] xl:p-[13px] 2xl:p-[15px] 3xl:p-[18px] rounded-radius16 shadow-bs1 w-[69%]">
                <Img
                  src="images/img_levelup1.png"
                  className="lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] xl:ml-[11px] 2xl:ml-[12px] 3xl:ml-[15px] lg:ml-[9px] 3xl:mt-[11px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
                  alt="levelupOne"
                />
                <Column className="lg:ml-[13px] xl:ml-[15px] 2xl:ml-[17px] 3xl:ml-[20px] w-[64%]">
                  <Text className="font-medium lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px] text-bluegray_900 w-[auto]">
                    Lorem ipusum reurerver vetuiev is thormation
                  </Text>
                  <Text className="font-light lg:mt-[6px] xl:mt-[7px] 2xl:mt-[8px] 3xl:mt-[9px] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                    Lorem ipusum reurerver vetuiev is ipusum reurerver vetuiev
                    reurerver{" "}
                  </Text>
                </Column>
                <Button
                  className="font-medium lg:ml-[13px] xl:ml-[15px] 2xl:ml-[17px] 3xl:ml-[20px] lg:mr-[31px] xl:mr-[36px] 2xl:mr-[40px] 3xl:mr-[48px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[16%]"
                  shape="RoundedBorder16"
                  size="lg"
                  variant="OutlinePurple100"
                >
                  Upgrade Now
                </Button>
              </Row>
              <Button
                className="flex lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] items-center justify-center lg:ml-[15px] xl:ml-[17px] 2xl:ml-[19px] 3xl:ml-[23px] lg:mt-[10px] xl:mt-[12px] 2xl:mt-[13px] 3xl:mt-[16px] lg:w-[33px] xl:w-[38px] 2xl:w-[43px] 3xl:w-[51px]"
                shape="icbRoundedBorder20"
                size="mdIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_group35.png"
                  className="flex items-center justify-center lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px]"
                  alt="GroupThirtyFive"
                />
              </Button>
              <Button
                className="flex lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] items-center justify-center 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] lg:mt-[10px] xl:mt-[12px] 2xl:mt-[13px] 3xl:mt-[16px] lg:w-[33px] xl:w-[38px] 2xl:w-[43px] 3xl:w-[51px]"
                shape="icbRoundedBorder20"
                size="mdIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_group36.png"
                  className="flex items-center justify-center lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px]"
                  alt="GroupThirtySix"
                />
              </Button>
            </Row>
            <Text className="font-medium 3xl:mt-[11px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] lg:text-[29px] xl:text-[33px] 2xl:text-[37px] 3xl:text-[45px] text-bluegray_900 w-[auto]">
              Dashboard
            </Text>
            <Row className="items-center justify-between lg:mt-[18px] xl:mt-[20px] 2xl:mt-[23px] 3xl:mt-[28px] w-[100%]">
              <Row className="bg-white_A700 lg:p-[16px] xl:p-[19px] 2xl:p-[21px] 3xl:p-[25px] rounded-radius47 shadow-bs1 w-[24%]">
                <Img
                  src="images/img_110.png"
                  className="lg:h-[36px] xl:h-[41px] 2xl:h-[46px] 3xl:h-[56px] lg:ml-[11px] xl:ml-[13px] 2xl:ml-[15px] 3xl:ml-[18px] xl:mt-[4px] lg:mt-[4px] 2xl:mt-[5px] 3xl:mt-[6px] lg:w-[35px] xl:w-[40px] 2xl:w-[45px] 3xl:w-[55px]"
                  alt="OneHundredTen"
                />
                <Text className="font-normal leading-[normal] lg:ml-[13px] xl:ml-[15px] 2xl:ml-[17px] 3xl:ml-[20px] lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-black_900 w-[42%]">
                  <span className="text-gray_600 font-kanit lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px]">
                    250
                    <br />
                  </span>
                  <span className="text-bluegray_900 font-kanit font-semibold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px]">
                    OPD Today
                  </span>
                </Text>
              </Row>
              <Row className="bg-white_A700 items-center justify-center lg:p-[16px] xl:p-[19px] 2xl:p-[21px] 3xl:p-[25px] rounded-radius47 shadow-bs1 w-[24%]">
                <Img
                  src="images/img_251.png"
                  className="lg:h-[38px] xl:h-[43px] 2xl:h-[48px] 3xl:h-[58px] lg:ml-[17px] xl:ml-[20px] 2xl:ml-[22px] 3xl:ml-[27px] mt-[4px] lg:w-[37px] xl:w-[42px] 2xl:w-[47px] 3xl:w-[57px]"
                  alt="TwoHundredFiftyOne"
                />
                <Text className="font-normal leading-[normal] lg:ml-[11px] xl:ml-[12px] 2xl:ml-[14px] 3xl:ml-[17px] lg:mr-[5px] xl:mr-[6px] 2xl:mr-[7px] 3xl:mr-[8px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-black_900 w-[58%]">
                  <span className="text-gray_600 font-kanit lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px]">
                    89
                    <br />
                  </span>
                  <span className="text-bluegray_900 font-kanit font-semibold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px]">
                    Relieved Today
                  </span>
                </Text>
              </Row>
              <Row className="bg-white_A700 items-center justify-center lg:p-[17px] xl:p-[20px] 2xl:p-[22px] 3xl:p-[27px] rounded-radius47 shadow-bs1 w-[24%]">
                <Img
                  src="images/img_32.png"
                  className="lg:h-[37px] xl:h-[42px] 2xl:h-[47px] 3xl:h-[57px] mb-[3px] lg:ml-[14px] xl:ml-[16px] 2xl:ml-[18px] 3xl:ml-[21px] w-[17%]"
                  alt="ThirtyTwo"
                />
                <Text className="font-normal leading-[normal] lg:ml-[11px] xl:ml-[13px] 2xl:ml-[15px] 3xl:ml-[18px] 2xl:mr-[10px] 3xl:mr-[12px] lg:mr-[8px] xl:mr-[9px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-black_900 w-[63%]">
                  <span className="text-gray_600 font-kanit lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px]">
                    300
                    <br />
                  </span>
                  <span className="text-bluegray_900 font-kanit font-semibold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px]">
                    In Patient Today
                  </span>
                </Text>
              </Row>
              <Row className="bg-white_A700 items-center justify-center lg:p-[18px] xl:p-[20px] 2xl:p-[23px] 3xl:p-[28px] rounded-radius47 shadow-bs1 w-[24%]">
                <Img
                  src="images/img_32.png"
                  className="lg:h-[37px] xl:h-[42px] 2xl:h-[47px] 3xl:h-[57px] mb-[1px] 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] w-[17%]"
                  alt="ThirtyThree"
                />
                <Text className="font-normal leading-[normal] xl:ml-[11px] 2xl:ml-[12px] 3xl:ml-[15px] lg:ml-[9px] lg:mr-[53px] xl:mr-[61px] 2xl:mr-[69px] 3xl:mr-[83px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-black_900 w-[39%]">
                  <span className="text-gray_600 font-kanit lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px]">
                    52
                    <br />
                  </span>
                  <span className="text-bluegray_900 font-kanit font-semibold lg:text-[14px] xl:text-[16px] 2xl:text-[18px] 3xl:text-[21px]">
                    Ventilator
                  </span>
                </Text>
              </Row>
            </Row>
            <Stack className="lg:h-[579px] xl:h-[662px] 2xl:h-[744px] 3xl:h-[893px] lg:mt-[21px] xl:mt-[24px] 2xl:mt-[27px] 3xl:mt-[33px] w-[100%]">
              <Stack className="absolute lg:h-[579px] xl:h-[662px] 2xl:h-[744px] 3xl:h-[893px] w-[100%]">
                <Stack className="absolute lg:h-[579px] xl:h-[662px] 2xl:h-[744px] 3xl:h-[893px] w-[100%]">
                  <Row className="absolute items-center justify-between top-[0] w-[100%]">
                    <Column className="bg-white_A700 lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] rounded-radius47 shadow-bs1 w-[49%]">
                      <Row className="justify-between lg:ml-[16px] xl:ml-[18px] 2xl:ml-[20px] 3xl:ml-[24px] lg:mt-[16px] xl:mt-[19px] 2xl:mt-[21px] 3xl:mt-[25px] w-[95%]">
                        <Text className="font-medium lg:mb-[6px] xl:mb-[7px] 2xl:mb-[8px] 3xl:mb-[9px] lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                          Hospital Survay
                          <br />
                        </Text>
                        <Text className="font-normal lg:mt-[13px] xl:mt-[15px] 2xl:mt-[17px] 3xl:mt-[20px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-black_900_99 w-[auto]">
                          New Patients Old Patients
                        </Text>
                      </Row>
                      <Row className="justify-end lg:mb-[14px] xl:mb-[16px] 2xl:mb-[18px] 3xl:mb-[21px] lg:ml-[19px] xl:ml-[22px] 2xl:ml-[25px] 3xl:ml-[30px] lg:mt-[16px] xl:mt-[18px] 2xl:mt-[20px] 3xl:mt-[24px] w-[95%]">
                        <Column className="w-[6%]">
                          <Text className="font-normal not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                            400
                          </Text>
                          <Text className="font-normal lg:mt-[30px] xl:mt-[34px] 2xl:mt-[38px] 3xl:mt-[46px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                            300
                          </Text>
                          <Text className="font-normal lg:mt-[30px] xl:mt-[35px] 2xl:mt-[39px] 3xl:mt-[47px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                            200
                          </Text>
                          <Text className="font-normal lg:mt-[30px] xl:mt-[35px] 2xl:mt-[39px] 3xl:mt-[47px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                            100
                          </Text>
                          <Text className="flex font-normal items-center 3xl:ml-[10px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] lg:mt-[30px] xl:mt-[35px] 2xl:mt-[39px] 3xl:mt-[47px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                            10
                          </Text>
                        </Column>
                        <Column className="items-center 3xl:ml-[11px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] lg:mt-[5px] xl:mt-[6px] 2xl:mt-[7px] 3xl:mt-[8px] w-[92%]">
                          <Stack className="lg:h-[171px] xl:h-[196px] 2xl:h-[220px] 3xl:h-[264px] w-[99%]">
                            <Column className="absolute items-center w-[100%]">
                              <Line className="bg-black_900_6c h-[1px] rotate-[1deg] w-[100%]" />
                              <Stack className="lg:h-[142px] xl:h-[162px] 2xl:h-[182px] 3xl:h-[219px] lg:mt-[27px] xl:mt-[31px] 2xl:mt-[35px] 3xl:mt-[42px] w-[100%]">
                                <Column className="absolute bottom-[0] items-center w-[100%]">
                                  <Line className="bg-black_900_6c h-[1px] rotate-[1deg] w-[100%]" />
                                  <Line className="bg-black_900_6c h-[1px] lg:mt-[39px] xl:mt-[45px] 2xl:mt-[51px] 3xl:mt-[61px] rotate-[1deg] w-[100%]" />
                                  <Line className="bg-black_900_6c h-[1px] lg:mt-[39px] xl:mt-[45px] 2xl:mt-[51px] 3xl:mt-[61px] rotate-[1deg] w-[100%]" />
                                  <Line className="bg-black_900_6c h-[1px] lg:mt-[39px] xl:mt-[45px] 2xl:mt-[51px] 3xl:mt-[61px] rotate-[1deg] w-[100%]" />
                                </Column>
                                <Img
                                  src="images/img_vector2.svg"
                                  className="absolute lg:h-[142px] xl:h-[162px] 2xl:h-[182px] 3xl:h-[219px] left-[1%] right-[2%] w-[96%]"
                                  alt="VectorTwo"
                                />
                              </Stack>
                            </Column>
                            <Img
                              src="images/img_vector1.svg"
                              className="absolute lg:h-[168px] xl:h-[192px] 2xl:h-[216px] 3xl:h-[259px] inset-[0] justify-center m-[auto] w-[97%]"
                              alt="VectorOne"
                            />
                          </Stack>
                          <Row className="justify-between mt-[4px] w-[100%]">
                            <Text className="font-normal my-[2px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Jan
                            </Text>
                            <Text className="font-normal mb-[3px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Feb
                            </Text>
                            <Text className="font-normal my-[2px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Mar
                            </Text>
                            <Text className="font-normal mt-[3px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Apr
                            </Text>
                            <Text className="font-normal my-[1px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              May
                            </Text>
                            <Text className="font-normal my-[2px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Jun
                            </Text>
                            <Text className="font-normal mb-[3px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Jul
                            </Text>
                            <Text className="font-normal my-[1px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Aug
                            </Text>
                            <Text className="font-normal mt-[2px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Sep
                            </Text>
                            <Text className="font-normal my-[2px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Oct
                            </Text>
                            <Text className="font-normal my-[2px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Nov
                            </Text>
                            <Text className="font-normal my-[2px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                              Dec
                            </Text>
                          </Row>
                        </Column>
                      </Row>
                    </Column>
                    <Row className="bg-white_A700 justify-end lg:p-[30px] xl:p-[35px] 2xl:p-[39px] 3xl:p-[47px] rounded-radius47 shadow-bs1 w-[48%]">
                      <Text className="font-normal mb-[1px] lg:mt-[219px] xl:mt-[250px] 2xl:mt-[281px] 3xl:mt-[338px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                        Wed
                      </Text>
                      <Text className="font-normal mb-[1px] lg:ml-[36px] xl:ml-[41px] 2xl:ml-[46px] 3xl:ml-[56px] lg:mt-[219px] xl:mt-[250px] 2xl:mt-[281px] 3xl:mt-[338px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                        Thu
                      </Text>
                      <Text className="font-normal mb-[1px] lg:ml-[36px] xl:ml-[41px] 2xl:ml-[46px] 3xl:ml-[56px] lg:mt-[219px] xl:mt-[250px] 2xl:mt-[281px] 3xl:mt-[338px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                        Fri
                      </Text>
                      <Text className="font-normal lg:ml-[44px] xl:ml-[51px] 2xl:ml-[57px] 3xl:ml-[69px] mr-[3px] lg:mt-[219px] xl:mt-[250px] 2xl:mt-[281px] 3xl:mt-[338px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                        Sat
                      </Text>
                    </Row>
                  </Row>
                  <Column className="absolute bottom-[0] left-[0] w-[67%]">
                    <Row className="items-center justify-center lg:ml-[245px] xl:ml-[280px] 2xl:ml-[315px] 3xl:ml-[378px] w-[18%]">
                      <div className="bg-purple_200 xl:h-[10px] 2xl:h-[11px] 3xl:h-[13px] lg:h-[9px] rounded-radius50 2xl:w-[10px] 3xl:w-[12px] lg:w-[8px] xl:w-[9px]"></div>
                      <div className="bg-deep_purple_100 xl:h-[10px] 2xl:h-[11px] 3xl:h-[13px] lg:h-[9px] 2xl:ml-[107px] 3xl:ml-[128px] lg:ml-[83px] xl:ml-[95px] rounded-radius50 2xl:w-[10px] 3xl:w-[12px] lg:w-[8px] xl:w-[9px]"></div>
                    </Row>
                    <Column className="lg:ml-[473px] xl:ml-[541px] 2xl:ml-[608px] 3xl:ml-[730px] lg:mt-[15px] xl:mt-[17px] 2xl:mt-[19px] 3xl:mt-[23px] w-[4%]">
                      <Text className="font-normal not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                        400
                      </Text>
                      <Text className="font-normal lg:mt-[30px] xl:mt-[34px] 2xl:mt-[38px] 3xl:mt-[46px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                        300
                      </Text>
                      <Text className="font-normal lg:mt-[30px] xl:mt-[35px] 2xl:mt-[39px] 3xl:mt-[47px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                        200
                      </Text>
                      <Text className="font-normal lg:mt-[30px] xl:mt-[35px] 2xl:mt-[39px] 3xl:mt-[47px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                        100
                      </Text>
                      <Text className="flex font-normal items-center 3xl:ml-[10px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] lg:mt-[30px] xl:mt-[35px] 2xl:mt-[39px] 3xl:mt-[47px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-gray_400 w-[auto]">
                        10
                      </Text>
                    </Column>
                    <Text className="font-normal lg:ml-[510px] xl:ml-[583px] 2xl:ml-[656px] 3xl:ml-[787px] mt-[1px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                      Mon
                    </Text>
                    <Column className="bg-white_A700 justify-center lg:mt-[51px] xl:mt-[59px] 2xl:mt-[66px] 3xl:mt-[79px] lg:p-[29px] xl:p-[33px] 2xl:p-[37px] 3xl:p-[45px] rounded-radius47 shadow-bs1 w-[100%]">
                      <Text className="font-medium ml-[1px] mt-[2px] lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                        Booked Appointment
                        <br />
                      </Text>
                      <Button
                        className="font-light lg:mt-[16px] xl:mt-[19px] 2xl:mt-[21px] 3xl:mt-[25px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[100%]"
                        size="xl"
                        variant="FillBlue50"
                      >
                        # Patient Name Assigned Doctor Date Diseases Actions
                      </Button>
                      <List
                        className="gap-[0] lg:mb-[14px] xl:mb-[16px] 2xl:mb-[18px] 3xl:mb-[22px] min-h-[auto] lg:ml-[23px] xl:ml-[26px] 2xl:ml-[29px] 3xl:ml-[35px] lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[94%]"
                        orientation="vertical"
                      >
                        <Row className="items-center lg:my-[12px] xl:my-[14px] 2xl:my-[16px] 3xl:my-[19px] w-[100%]">
                          <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] w-[82%]">
                            <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] right-[0] w-[13%]"></div>
                            <Text className="absolute bottom-[13%] font-normal left-[0] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                              <span className="text-bluegray_900 font-kanit">
                                001 Ramesh Kumar{" "}
                              </span>
                              <span className="text-bluegray_500 font-kanit font-medium">
                                {" "}
                                Dr.Jacob Ryan
                              </span>
                              <span className="text-bluegray_900 font-kanit">
                                {" "}
                                12 Jan 2022{" "}
                              </span>
                              <span className="text-red_50 font-kanit">
                                {" "}
                                Fever{" "}
                              </span>
                              <span className="text-bluegray_900 font-kanit">
                                {" "}
                              </span>
                            </Text>
                          </Stack>
                          <Button
                            className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[30px] xl:ml-[35px] 2xl:ml-[39px] 3xl:ml-[47px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                            shape="icbRoundedBorder8"
                          >
                            <Img
                              src="images/img_group49.png"
                              className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                              alt="GroupFortyNine"
                            />
                          </Button>
                          <Button
                            className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[14px] xl:ml-[16px] 2xl:ml-[18px] 3xl:ml-[21px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                            shape="icbRoundedBorder8"
                          >
                            <Img
                              src="images/img_group48.png"
                              className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                              alt="GroupFortyEight"
                            />
                          </Button>
                        </Row>
                        <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                        <Row className="items-center lg:my-[12px] xl:my-[14px] 2xl:my-[16px] 3xl:my-[19px] w-[100%]">
                          <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] w-[82%]">
                            <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] right-[0] w-[13%]"></div>
                            <Text className="absolute bottom-[13%] font-normal inset-x-[0] mx-[auto] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[max-content]">
                              <span className="text-bluegray_900 font-kanit">
                                001 Ramesh Kumar{" "}
                              </span>
                              <span className="text-bluegray_500 font-kanit font-medium">
                                {" "}
                                Dr.Jacob Ryan
                              </span>
                              <span className="text-bluegray_900 font-kanit">
                                {" "}
                                12 Jan 2022{" "}
                              </span>
                              <span className="text-red_50 font-kanit">
                                {" "}
                                Cholera
                              </span>
                              <span className="text-bluegray_900 font-kanit">
                                {" "}
                              </span>
                            </Text>
                          </Stack>
                          <Button
                            className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[30px] xl:ml-[35px] 2xl:ml-[39px] 3xl:ml-[47px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                            shape="icbRoundedBorder8"
                          >
                            <Img
                              src="images/img_group49.png"
                              className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                              alt="GroupFortySeven"
                            />
                          </Button>
                          <Button
                            className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[14px] xl:ml-[16px] 2xl:ml-[18px] 3xl:ml-[21px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                            shape="icbRoundedBorder8"
                          >
                            <Img
                              src="images/img_group48.png"
                              className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                              alt="GroupFortySix"
                            />
                          </Button>
                        </Row>
                        <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                        <Row className="items-center lg:my-[12px] xl:my-[14px] 2xl:my-[16px] 3xl:my-[19px] w-[100%]">
                          <Stack className="lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] w-[82%]">
                            <div className="absolute bg-red_300 lg:h-[17px] xl:h-[19px] 2xl:h-[21px] 3xl:h-[25px] right-[0] w-[13%]"></div>
                            <Text className="absolute bottom-[13%] font-normal left-[0] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                              <span className="text-bluegray_900 font-kanit">
                                001 Ramesh Kumar{" "}
                              </span>
                              <span className="text-bluegray_500 font-kanit font-medium">
                                {" "}
                                Dr.Jacob Ryan
                              </span>
                              <span className="text-bluegray_900 font-kanit">
                                {" "}
                                12 Jan 2022{" "}
                              </span>
                              <span className="text-red_50 font-kanit">
                                {" "}
                                Fever{" "}
                              </span>
                              <span className="text-bluegray_900 font-kanit">
                                {" "}
                              </span>
                            </Text>
                          </Stack>
                          <Button
                            className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[30px] xl:ml-[35px] 2xl:ml-[39px] 3xl:ml-[47px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                            shape="icbRoundedBorder8"
                          >
                            <Img
                              src="images/img_group49.png"
                              className="flex items-center justify-center lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px]"
                              alt="GroupFortyFive"
                            />
                          </Button>
                          <Button
                            className="flex lg:h-[21px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[33px] items-center justify-center lg:ml-[14px] xl:ml-[16px] 2xl:ml-[18px] 3xl:ml-[21px] lg:w-[21px] xl:w-[24px] 2xl:w-[27px] 3xl:w-[32px]"
                            shape="icbRoundedBorder8"
                          >
                            <Img
                              src="images/img_group48.png"
                              className="flex items-center justify-center lg:h-[11px] xl:h-[13px] 2xl:h-[14px] 3xl:h-[17px]"
                              alt="GroupFortyFour"
                            />
                          </Button>
                        </Row>
                      </List>
                    </Column>
                  </Column>
                </Stack>
                <Column className="absolute h-[max-content] inset-y-[0] my-[auto] right-[1%] w-[43%]">
                  <Text className="font-medium lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                    Common Diseases Report
                    <br />
                  </Text>
                  <Column className="justify-end lg:ml-[32px] xl:ml-[36px] 2xl:ml-[41px] 3xl:ml-[49px] lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[43px] 3xl:pl-[103px] lg:pl-[67px] xl:pl-[76px] 2xl:pl-[86px] 3xl:pt-[103px] lg:pt-[67px] xl:pt-[76px] 2xl:pt-[86px] w-[91%]">
                    <Text className="font-normal lg:mr-[250px] xl:mr-[286px] 2xl:mr-[322px] 3xl:mr-[386px] lg:mt-[106px] xl:mt-[121px] 2xl:mt-[136px] 3xl:mt-[164px] not-italic lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900 w-[auto]">
                      Tue
                    </Text>
                    <Text className="font-medium lg:ml-[42px] xl:ml-[48px] 2xl:ml-[54px] 3xl:ml-[64px] lg:mr-[119px] xl:mr-[136px] 2xl:mr-[154px] 3xl:mr-[184px] 2xl:mt-[100px] 3xl:mt-[121px] lg:mt-[78px] xl:mt-[89px] lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                      Doctors Notes
                      <br />
                    </Text>
                    <Input
                      className="font-light p-[0] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] placeholder:text-bluegray_900_ab text-bluegray_900_ab w-[100%]"
                      wrapClassName="2xl:ml-[54px] 2xl:mt-[18px] 3xl:ml-[64px] 3xl:mt-[22px] lg:ml-[42px] lg:mt-[14px] w-[84%] xl:ml-[48px] xl:mt-[16px]"
                      type="text"
                      name="language Five"
                      placeholder="#           Doctors  Name    	                        Status"
                      size="sm"
                      variant="FillBlue50"
                    ></Input>
                    <List
                      className="gap-[0] min-h-[auto] lg:ml-[54px] xl:ml-[62px] 2xl:ml-[70px] 3xl:ml-[84px] lg:mr-[3px] 2xl:mr-[4px] xl:mr-[4px] 3xl:mr-[5px] xl:mt-[10px] 2xl:mt-[11px] 3xl:mt-[14px] lg:mt-[9px] w-[78%]"
                      orientation="vertical"
                    >
                      <Row className="items-center 2xl:my-[10px] 3xl:my-[12px] lg:my-[8px] xl:my-[9px] w-[100%]">
                        <Img
                          src="images/img_rectangle40.png"
                          className="lg:h-[26px] xl:h-[29px] 2xl:h-[33px] 3xl:h-[39px] rounded-radius8 lg:w-[25px] xl:w-[28px] 2xl:w-[32px] 3xl:w-[38px]"
                          alt="RectangleForty"
                        />
                        <Text className="font-normal 3xl:ml-[11px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                          {" "}
                          Dr.Jacob Ryan{" "}
                        </Text>
                        <Button
                          className="font-light lg:ml-[63px] xl:ml-[72px] 2xl:ml-[81px] 3xl:ml-[98px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[25%]"
                          size="sm"
                          variant="OutlineDeeppurple200a3"
                        >
                          Available
                        </Button>
                      </Row>
                      <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                      <Row className="items-center 2xl:my-[10px] 3xl:my-[12px] lg:my-[8px] xl:my-[9px] w-[100%]">
                        <Img
                          src="images/img_rectangle40.png"
                          className="lg:h-[26px] xl:h-[29px] 2xl:h-[33px] 3xl:h-[39px] rounded-radius8 lg:w-[25px] xl:w-[28px] 2xl:w-[32px] 3xl:w-[38px]"
                          alt="RectangleFortyOne One"
                        />
                        <Text className="font-normal 3xl:ml-[11px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                          {" "}
                          Dr.Rubina Delayer{" "}
                        </Text>
                        <Button
                          className="font-light lg:ml-[46px] xl:ml-[53px] 2xl:ml-[60px] 3xl:ml-[72px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[25%]"
                          size="sm"
                          variant="OutlineDeeppurple200a3"
                        >
                          Available
                        </Button>
                      </Row>
                      <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                      <Row className="items-center 2xl:my-[10px] 3xl:my-[12px] lg:my-[8px] xl:my-[9px] w-[100%]">
                        <Img
                          src="images/img_rectangle40.png"
                          className="lg:h-[26px] xl:h-[29px] 2xl:h-[33px] 3xl:h-[39px] rounded-radius8 lg:w-[25px] xl:w-[28px] 2xl:w-[32px] 3xl:w-[38px]"
                          alt="RectangleFortyTwo"
                        />
                        <Text className="font-normal 3xl:ml-[11px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                          {" "}
                          Dr.Smith Rayen{" "}
                        </Text>
                        <Button
                          className="font-light lg:ml-[58px] xl:ml-[67px] 2xl:ml-[75px] 3xl:ml-[90px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[25%]"
                          size="sm"
                          variant="OutlineTeal200"
                        >
                          Available
                        </Button>
                      </Row>
                      <Line className="self-center w-[100%] h-[1px] bg-indigo_50" />
                      <Row className="items-center 2xl:my-[10px] 3xl:my-[12px] lg:my-[8px] xl:my-[9px] w-[100%]">
                        <Img
                          src="images/img_rectangle40.png"
                          className="lg:h-[26px] xl:h-[29px] 2xl:h-[33px] 3xl:h-[39px] rounded-radius8 lg:w-[25px] xl:w-[28px] 2xl:w-[32px] 3xl:w-[38px]"
                          alt="RectangleFortyThree"
                        />
                        <Text className="font-normal 3xl:ml-[11px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] not-italic xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-bluegray_900 w-[auto]">
                          {" "}
                          Dr.Jacob Ryan{" "}
                        </Text>
                        <Button
                          className="font-light lg:ml-[63px] xl:ml-[72px] 2xl:ml-[81px] 3xl:ml-[98px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[25%]"
                          size="sm"
                          variant="OutlineRed300"
                        >
                          Absend
                        </Button>
                      </Row>
                    </List>
                  </Column>
                </Column>
              </Stack>
              <Row className="absolute items-end justify-between right-[5%] top-[13%] w-[35%]">
                <List
                  className="lg:gap-[45px] xl:gap-[52px] 2xl:gap-[58px] 3xl:gap-[70px] grid grid-cols-2 min-h-[auto] w-[23%]"
                  orientation="horizontal"
                >
                  <Column className="bg-indigo_100 items-center justify-end lg:pt-[35px] xl:pt-[40px] 2xl:pt-[45px] 3xl:pt-[55px] w-[100%]">
                    <Column className="bg-blue_200 items-center justify-end lg:pt-[44px] xl:pt-[51px] 2xl:pt-[57px] 3xl:pt-[69px] w-[100%]">
                      <Column className="bg-purple_200 items-center justify-end lg:pt-[21px] xl:pt-[24px] 2xl:pt-[27px] 3xl:pt-[33px] w-[100%]">
                        <div className="bg-red_A100 3xl:h-[105px] lg:h-[68px] xl:h-[78px] 2xl:h-[88px] w-[100%]"></div>
                      </Column>
                    </Column>
                  </Column>
                  <Column className="bg-indigo_100 items-center justify-end lg:mt-[23px] xl:mt-[26px] 2xl:mt-[29px] 3xl:mt-[35px] lg:pt-[37px] xl:pt-[42px] 2xl:pt-[47px] 3xl:pt-[57px] w-[100%]">
                    <Column className="bg-blue_200 items-center justify-end lg:pt-[20px] xl:pt-[23px] 2xl:pt-[26px] 3xl:pt-[31px] w-[100%]">
                      <Column className="bg-purple_200 items-center justify-end 3xl:pt-[104px] lg:pt-[67px] xl:pt-[77px] 2xl:pt-[87px] w-[100%]">
                        <div className="bg-red_A100 lg:h-[22px] xl:h-[25px] 2xl:h-[28px] 3xl:h-[34px] w-[100%]"></div>
                      </Column>
                    </Column>
                  </Column>
                </List>
                <Column className="bg-blue_200 items-center justify-end lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[65px] lg:pt-[51px] xl:pt-[59px] 2xl:pt-[66px] 3xl:pt-[79px] w-[4%]">
                  <Column className="bg-purple_200 items-center justify-end 3xl:pt-[11px] lg:pt-[7px] xl:pt-[8px] 2xl:pt-[9px] w-[100%]">
                    <div className="bg-red_A100 3xl:h-[105px] lg:h-[68px] xl:h-[78px] 2xl:h-[88px] w-[100%]"></div>
                  </Column>
                </Column>
                <Column className="bg-indigo_100 items-center justify-end 3xl:mt-[100px] lg:mt-[65px] xl:mt-[74px] 2xl:mt-[83px] lg:pt-[33px] xl:pt-[38px] 2xl:pt-[43px] 3xl:pt-[51px] w-[4%]">
                  <Column className="bg-blue_200 items-center justify-end lg:pt-[21px] xl:pt-[24px] 2xl:pt-[27px] 3xl:pt-[32px] w-[100%]">
                    <Column className="bg-purple_200 items-center justify-end lg:pt-[23px] xl:pt-[26px] 2xl:pt-[29px] 3xl:pt-[35px] w-[100%]">
                      <div className="bg-red_A100 lg:h-[28px] xl:h-[32px] 2xl:h-[36px] 3xl:h-[43px] w-[100%]"></div>
                    </Column>
                  </Column>
                </Column>
                <Column className="bg-indigo_100 items-center justify-end lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[44px] 3xl:pt-[108px] lg:pt-[70px] xl:pt-[80px] 2xl:pt-[90px] w-[4%]">
                  <Column className="bg-blue_200 items-center justify-end lg:pt-[21px] xl:pt-[24px] 2xl:pt-[27px] 3xl:pt-[32px] w-[100%]">
                    <Column className="bg-purple_200 items-center justify-end lg:pt-[16px] xl:pt-[19px] 2xl:pt-[21px] 3xl:pt-[25px] w-[100%]">
                      <div className="bg-red_A100 lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] w-[100%]"></div>
                    </Column>
                  </Column>
                </Column>
                <Column className="bg-indigo_100 items-center justify-end mt-[4px] lg:pt-[55px] xl:pt-[63px] 2xl:pt-[71px] 3xl:pt-[85px] w-[4%]">
                  <Column className="bg-blue_200 items-center justify-end lg:pt-[22px] xl:pt-[25px] 2xl:pt-[28px] 3xl:pt-[34px] w-[100%]">
                    <Column className="bg-purple_200 items-center justify-end lg:pt-[21px] xl:pt-[24px] 2xl:pt-[27px] 3xl:pt-[33px] w-[100%]">
                      <div className="bg-red_A100 3xl:h-[105px] lg:h-[68px] xl:h-[78px] 2xl:h-[88px] w-[100%]"></div>
                    </Column>
                  </Column>
                </Column>
              </Row>
            </Stack>
          </Column>
        </Stack>
        <Row className="absolute left-[4%] top-[7%] w-[78%]">
          <Column className="lg:mt-[15px] xl:mt-[17px] 2xl:mt-[19px] 3xl:mt-[23px] w-[97%]">
            <Row className="lg:ml-[5px] xl:ml-[6px] 2xl:ml-[7px] 3xl:ml-[8px] w-[11%]">
              <Stack className="bg-white_A700 lg:h-[49px] xl:h-[57px] 2xl:h-[64px] 3xl:h-[76px] px-[3px] rounded-radius50 shadow-bs5 lg:w-[49px] xl:w-[56px] 2xl:w-[63px] 3xl:w-[75px]">
                <Img
                  src="images/img_man1.png"
                  className="absolute bottom-[0] lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] inset-x-[0] mx-[auto] lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
                  alt="manOne"
                />
              </Stack>
              <Button
                className="flex lg:h-[23px] xl:h-[26px] 2xl:h-[29px] 3xl:h-[35px] items-center justify-center lg:ml-[18px] xl:ml-[20px] 2xl:ml-[23px] 3xl:ml-[28px] lg:mt-[6px] xl:mt-[7px] 2xl:mt-[8px] 3xl:mt-[9px] lg:w-[22px] xl:w-[25px] 2xl:w-[28px] 3xl:w-[34px]"
                shape="icbRoundedBorder8"
                variant="icbOutlineDeeppurple100a31_2"
              >
                <Img
                  src="images/img_group53.png"
                  className="flex items-center justify-center lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px]"
                  alt="GroupFiftyThree"
                />
              </Button>
            </Row>
            <Text className="font-normal lg:leading-[16px] xl:leading-[19px] 2xl:leading-[21px] 3xl:leading-[25px] lg:mt-[4px] xl:mt-[5px] 2xl:mt-[6px] 3xl:mt-[7px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 text-center w-[7%]">
              <span className="text-bluegray_900 font-kanit lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px]">
                Sarah Smith
                <br />
                <br />
              </span>
              <span className="text-bluegray_900 font-kanit uppercase font-medium lg:text-[9px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px]">
                Admin
              </span>
            </Text>
            <Column className="items-center lg:ml-[10px] xl:ml-[12px] 2xl:ml-[13px] 3xl:ml-[16px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[64px] w-[16%]">
              <Button
                className="flex lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] items-center justify-center lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
                shape="icbRoundedBorder20"
                size="lgIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_volume.svg"
                  className="flex items-center justify-center lg:h-[24px] xl:h-[27px] 2xl:h-[30px] 3xl:h-[36px]"
                  alt="volume"
                />
              </Button>
              <Row className="bg-gray_401 items-center justify-end lg:mt-[18px] xl:mt-[20px] 2xl:mt-[23px] 3xl:mt-[28px] lg:p-[11px] xl:p-[13px] 2xl:p-[15px] 3xl:p-[18px] rounded-radius20 shadow-bs1 w-[91%]">
                <Img
                  src="images/img_appointment1.png"
                  className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] my-[2px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                  alt="appointmentOne"
                />
                <Text className="font-normal 3xl:ml-[10px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                  Appointment
                </Text>
              </Row>
              <Img
                src="images/img_settinglines1.png"
                className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] 3xl:mt-[105px] lg:mt-[68px] xl:mt-[78px] 2xl:mt-[88px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                alt="settinglinesOne"
              />
              <Img
                src="images/img_team1.png"
                className="lg:h-[19px] xl:h-[22px] 2xl:h-[25px] 3xl:h-[30px] lg:mt-[31px] xl:mt-[36px] 2xl:mt-[40px] 3xl:mt-[48px] lg:w-[18px] xl:w-[21px] 2xl:w-[24px] 3xl:w-[29px]"
                alt="teamOne"
              />
              <Img
                src="images/img_securitypaymen.png"
                className="lg:h-[21px] xl:h-[24px] 2xl:h-[27px] 3xl:h-[32px] lg:mt-[26px] xl:mt-[30px] 2xl:mt-[34px] 3xl:mt-[41px] lg:w-[20px] xl:w-[23px] 2xl:w-[26px] 3xl:w-[31px]"
                alt="securitypaymen"
              />
              <Row className="bg-bluegray_100 justify-end lg:mt-[60px] xl:mt-[69px] 2xl:mt-[78px] 3xl:mt-[94px] xl:p-[11px] 2xl:p-[12px] 3xl:p-[15px] lg:p-[9px] rounded-radius20 shadow-bs1 w-[100%]">
                <Img
                  src="images/img_appointment1.png"
                  className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] lg:mb-[6px] xl:mb-[7px] 2xl:mb-[8px] 3xl:mb-[9px] mt-[1px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                  alt="appointmentTwo"
                />
                <Text className="font-normal ml-[4px] lg:mt-[3px] 2xl:mt-[4px] xl:mt-[4px] 3xl:mt-[5px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                  Medical Records
                </Text>
              </Row>
              <Img
                src="images/img_power2.png"
                className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] lg:mt-[151px] xl:mt-[172px] 2xl:mt-[194px] 3xl:mt-[233px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                alt="powerTwo"
              />
            </Column>
          </Column>
          <Text className="font-medium rotate-[41deg] lg:text-[22px] xl:text-[25px] 2xl:text-[28px] 3xl:text-[34px] text-black_900_75 text-shadow-ts w-[auto]">
            +
          </Text>
        </Row>
      </Stack>
    </>
  );
};

export default DashboardPage;
