import React from "react";

import { Stack, Column, Row, Img, Button, Text, Input, Line } from "components";

const FormPage = () => {
  return (
    <>
      <Stack className="bg-gradient1  font-kanit xl:h-[1125px] 2xl:h-[1266px] 3xl:h-[1519px] lg:h-[984px] mx-[auto] lg:px-[41px] xl:px-[47px] 2xl:px-[53px] 3xl:px-[63px] w-[100%]">
        <Stack className="absolute 2xl:h-[1109px] 3xl:h-[1331px] lg:h-[862px] xl:h-[986px] inset-[0] justify-center m-[auto] w-[92%]">
          <Column className="absolute bg-white_A700_90 items-end lg:pl-[128px] xl:pl-[147px] 2xl:pl-[165px] 3xl:pl-[198px] w-[100%]">
            <div className="bg-gradient2  2xl:h-[1109px] 3xl:h-[1331px] lg:h-[862px] xl:h-[986px] w-[100%]"></div>
          </Column>
          <Column className="absolute right-[3%] top-[4%] w-[82%]">
            <Row className="items-center w-[100%]">
              <Img
                src="images/img_file1.png"
                className="lg:h-[49px] xl:h-[56px] 2xl:h-[63px] 3xl:h-[75px] w-[15%]"
                alt="fileOne"
              />
              <Button
                className="flex lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] items-center justify-center lg:ml-[633px] xl:ml-[724px] 2xl:ml-[815px] 3xl:ml-[977px] lg:w-[33px] xl:w-[38px] 2xl:w-[43px] 3xl:w-[51px]"
                shape="icbRoundedBorder20"
                size="mdIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_group35.png"
                  className="flex items-center justify-center lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px]"
                  alt="GroupFive"
                />
              </Button>
              <Button
                className="flex lg:h-[34px] xl:h-[39px] 2xl:h-[44px] 3xl:h-[52px] items-center justify-center 2xl:ml-[10px] 3xl:ml-[12px] lg:ml-[8px] xl:ml-[9px] lg:w-[33px] xl:w-[38px] 2xl:w-[43px] 3xl:w-[51px]"
                shape="icbRoundedBorder20"
                size="mdIcn"
                variant="icbOutlineDeeppurple100a3"
              >
                <Img
                  src="images/img_group36.png"
                  className="flex items-center justify-center lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px]"
                  alt="GroupSix"
                />
              </Button>
            </Row>
            <Text className="font-medium lg:mt-[32px] xl:mt-[36px] 2xl:mt-[41px] 3xl:mt-[49px] lg:text-[29px] xl:text-[33px] 2xl:text-[37px] 3xl:text-[45px] text-bluegray_900 w-[auto]">
              Patient
            </Text>
            <Column className="bg-white_A700 items-center lg:mt-[23px] xl:mt-[27px] 2xl:mt-[30px] 3xl:mt-[36px] lg:p-[16px] xl:p-[18px] 2xl:p-[20px] 3xl:p-[24px] rounded-radius47 shadow-bs1 w-[100%]">
              <Row className="justify-between xl:mt-[11px] 2xl:mt-[12px] 3xl:mt-[15px] lg:mt-[9px] w-[97%]">
                <Text className="font-medium lg:text-[16px] xl:text-[19px] 2xl:text-[21px] 3xl:text-[25px] text-bluegray_900 w-[auto]">
                  Add Patient Information
                  <br />
                </Text>
                <Button
                  className="font-semibold 2xl:mt-[10px] 3xl:mt-[12px] lg:mt-[8px] xl:mt-[9px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[11%]"
                  shape="RoundedBorder5"
                  size="md"
                  variant="FillRed300"
                >
                  Patient List
                </Button>
              </Row>
              <Row className="items-end justify-between lg:mt-[18px] xl:mt-[20px] 2xl:mt-[23px] 3xl:mt-[28px] w-[97%]">
                <Input
                  className="font-medium p-[0] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] placeholder:text-bluegray_900 text-bluegray_900 w-[100%]"
                  wrapClassName="w-[48%]"
                  type="text"
                  name="Group128"
                  placeholder={`First Name *
`}
                  size="xl"
                  variant="UnderLineBluegray900"
                ></Input>
                <Input
                  className="font-light p-[0] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] placeholder:text-bluegray_900_cc text-bluegray_900_cc w-[100%]"
                  wrapClassName="2xl:mt-[13px] 3xl:mt-[16px] lg:mt-[10px] w-[47%] xl:mt-[12px]"
                  type="text"
                  name="Group130"
                  placeholder={`Last Name *
`}
                ></Input>
              </Row>
              <Row className="justify-between lg:mt-[34px] xl:mt-[39px] 2xl:mt-[44px] 3xl:mt-[52px] w-[97%]">
                <Input
                  className="font-light p-[0] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] placeholder:text-bluegray_900_cc text-bluegray_900_cc w-[100%]"
                  wrapClassName="w-[48%]"
                  type="email"
                  name="Group141"
                  placeholder={`Email Id *
`}
                ></Input>
                <Input
                  className="font-light p-[0] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] placeholder:text-bluegray_900_cc text-bluegray_900_cc w-[100%]"
                  wrapClassName="w-[22%]"
                  type="number"
                  name="Group132"
                  placeholder={`Mobile Number *
`}
                ></Input>
                <Input
                  className="font-light p-[0] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] placeholder:text-bluegray_900_cc text-bluegray_900_cc w-[100%]"
                  wrapClassName="mt-[1px] w-[22%]"
                  name="Group134"
                  placeholder={`Age *
`}
                ></Input>
              </Row>
              <Row className="lg:mt-[31px] xl:mt-[36px] 2xl:mt-[40px] 3xl:mt-[48px] w-[97%]">
                <Column className="mt-[4px] w-[53%]">
                  <Row className="ml-[4px] w-[89%]">
                    <Text className="font-light mb-[4px] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      Gender *<br />
                    </Text>
                    <Img
                      src="images/img_downarrow1.png"
                      className="lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] lg:ml-[113px] xl:ml-[129px] 2xl:ml-[145px] 3xl:ml-[175px] mt-[4px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                      alt="downarrowOne"
                    />
                    <Text className="font-light mb-[4px] lg:ml-[32px] xl:ml-[36px] 2xl:ml-[41px] 3xl:ml-[49px] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      {" "}
                      Marital Status *<br />
                    </Text>
                    <Img
                      src="images/img_downarrow1.png"
                      className="lg:h-[12px] xl:h-[13px] 2xl:h-[15px] 3xl:h-[18px] 2xl:ml-[103px] 3xl:ml-[124px] lg:ml-[80px] xl:ml-[92px] mt-[4px] lg:w-[11px] xl:w-[12px] 2xl:w-[14px] 3xl:w-[17px]"
                      alt="downarrowTwo"
                    />
                  </Row>
                  <Row className="items-center lg:mt-[6px] xl:mt-[7px] 2xl:mt-[8px] 3xl:mt-[9px] w-[90%]">
                    <Line className="bg-bluegray_900_63 h-[1px] w-[47%]" />
                    <Line className="bg-bluegray_900_63 h-[1px] lg:ml-[20px] xl:ml-[23px] 2xl:ml-[26px] 3xl:ml-[31px] w-[47%]" />
                  </Row>
                </Column>
                <Input
                  className="font-light p-[0] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] placeholder:text-bluegray_900_cc text-bluegray_900_cc w-[100%]"
                  wrapClassName="2xl:mt-[6px] 3xl:mt-[7px] lg:mt-[4px] w-[22%] xl:mt-[5px]"
                  name="Group136"
                  placeholder={`Blood Group *
`}
                  size="lg"
                ></Input>
                <Column className="items-center lg:ml-[20px] xl:ml-[23px] 2xl:ml-[26px] 3xl:ml-[31px] w-[22%]">
                  <Row className="justify-between w-[95%]">
                    <Text className="font-light mt-[4px] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      Date of Birth *<br />
                    </Text>
                    <Img
                      src="images/img_calendar1.png"
                      className="lg:h-[17px] xl:h-[20px] 2xl:h-[22px] 3xl:h-[26px] lg:w-[16px] xl:w-[19px] 2xl:w-[21px] 3xl:w-[25px]"
                      alt="calendarOne"
                    />
                  </Row>
                  <Line className="bg-bluegray_900_63 h-[1px] 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] w-[100%]" />
                </Column>
              </Row>
              <Input
                className="font-light p-[0] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] placeholder:text-bluegray_900_cc text-bluegray_900_cc w-[100%]"
                wrapClassName="2xl:mt-[44px] 3xl:mt-[52px] lg:mt-[34px] w-[97%] xl:mt-[39px]"
                name="Group146"
                placeholder="Address"
              ></Input>
              <Row className="lg:mb-[21px] xl:mb-[24px] 2xl:mb-[27px] 3xl:mb-[33px] lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[44px] w-[98%]">
                <Column className="mt-[1px] w-[52%]">
                  <Row className="ml-[4px] w-[91%]">
                    <Text className="font-light lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] text-bluegray_900_cc w-[auto]">
                      Upload Image
                    </Text>
                    <Button
                      className="font-light lg:ml-[238px] xl:ml-[272px] 2xl:ml-[306px] 3xl:ml-[367px] mt-[2px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[19%]"
                      size="sm"
                      variant="FillTeal200"
                    >
                      Browe Image
                    </Button>
                  </Row>
                  <Line className="bg-bluegray_900_63 h-[1px] mt-[1px] w-[92%]" />
                </Column>
                <Column className="items-end w-[48%]">
                  <Input
                    className="font-light p-[0] lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px] placeholder:text-bluegray_900_cc text-bluegray_900_cc w-[100%]"
                    wrapClassName="mr-[3px] w-[99%]"
                    name="Group144"
                    placeholder="Sugger"
                  ></Input>
                  <Button
                    className="font-medium lg:mt-[25px] xl:mt-[28px] 2xl:mt-[32px] 3xl:mt-[38px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px] lg:text-[9px] text-center w-[23%]"
                    shape="RoundedBorder16"
                    size="lg"
                    variant="OutlinePurple100"
                  >
                    Submit{" "}
                  </Button>
                </Column>
              </Row>
            </Column>
          </Column>
        </Stack>
        <Column className="absolute left-[4%] top-[8%] w-[13%]">
          <Row className="lg:ml-[5px] xl:ml-[6px] 2xl:ml-[7px] 3xl:ml-[8px] w-[61%]">
            <Stack className="bg-white_A700 lg:h-[49px] xl:h-[57px] 2xl:h-[64px] 3xl:h-[76px] px-[3px] rounded-radius50 shadow-bs5 lg:w-[49px] xl:w-[56px] 2xl:w-[63px] 3xl:w-[75px]">
              <Img
                src="images/img_man1.png"
                className="absolute bottom-[0] lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] inset-x-[0] mx-[auto] lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
                alt="manOne"
              />
            </Stack>
            <Button
              className="flex lg:h-[23px] xl:h-[26px] 2xl:h-[29px] 3xl:h-[35px] items-center justify-center lg:ml-[18px] xl:ml-[20px] 2xl:ml-[23px] 3xl:ml-[28px] lg:mt-[6px] xl:mt-[7px] 2xl:mt-[8px] 3xl:mt-[9px] lg:w-[22px] xl:w-[25px] 2xl:w-[28px] 3xl:w-[34px]"
              shape="icbRoundedBorder8"
              variant="icbOutlineDeeppurple100a31_2"
            >
              <Img
                src="images/img_group53.png"
                className="flex items-center justify-center lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px]"
                alt="GroupEleven"
              />
            </Button>
          </Row>
          <Text className="font-normal lg:leading-[16px] xl:leading-[19px] 2xl:leading-[21px] 3xl:leading-[25px] lg:mt-[4px] xl:mt-[5px] 2xl:mt-[6px] 3xl:mt-[7px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 text-center w-[40%]">
            <span className="text-bluegray_900 font-kanit lg:text-[11px] xl:text-[12px] 2xl:text-[14px] 3xl:text-[17px]">
              Sarah Smith
              <br />
              <br />
            </span>
            <span className="text-bluegray_900 font-kanit uppercase font-medium lg:text-[9px] xl:text-[11px] 2xl:text-[12px] 3xl:text-[15px]">
              Admin
            </span>
          </Text>
          <Column className="items-center lg:ml-[10px] xl:ml-[12px] 2xl:ml-[13px] 3xl:ml-[16px] lg:mt-[42px] xl:mt-[48px] 2xl:mt-[54px] 3xl:mt-[64px] w-[93%]">
            <Button
              className="flex lg:h-[45px] xl:h-[52px] 2xl:h-[58px] 3xl:h-[70px] items-center justify-center lg:w-[44px] xl:w-[51px] 2xl:w-[57px] 3xl:w-[69px]"
              shape="icbRoundedBorder20"
              size="lgIcn"
              variant="icbOutlineDeeppurple100a3"
            >
              <Img
                src="images/img_volume.svg"
                className="flex items-center justify-center lg:h-[24px] xl:h-[27px] 2xl:h-[30px] 3xl:h-[36px]"
                alt="volume"
              />
            </Button>
            <Row className="bg-gray_401 items-center justify-end lg:mt-[18px] xl:mt-[20px] 2xl:mt-[23px] 3xl:mt-[28px] lg:p-[11px] xl:p-[13px] 2xl:p-[15px] 3xl:p-[18px] rounded-radius20 shadow-bs1 w-[91%]">
              <Img
                src="images/img_appointment1.png"
                className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] my-[2px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                alt="appointmentOne"
              />
              <Text className="font-normal 3xl:ml-[10px] lg:ml-[7px] xl:ml-[8px] 2xl:ml-[9px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                Appointment
              </Text>
            </Row>
            <Img
              src="images/img_settinglines1.png"
              className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] 3xl:mt-[105px] lg:mt-[68px] xl:mt-[78px] 2xl:mt-[88px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
              alt="settinglinesOne"
            />
            <Img
              src="images/img_team1.png"
              className="lg:h-[19px] xl:h-[22px] 2xl:h-[25px] 3xl:h-[30px] lg:mt-[31px] xl:mt-[36px] 2xl:mt-[40px] 3xl:mt-[48px] lg:w-[18px] xl:w-[21px] 2xl:w-[24px] 3xl:w-[29px]"
              alt="teamOne"
            />
            <Img
              src="images/img_securitypaymen.png"
              className="lg:h-[21px] xl:h-[24px] 2xl:h-[27px] 3xl:h-[32px] lg:mt-[26px] xl:mt-[30px] 2xl:mt-[34px] 3xl:mt-[41px] lg:w-[20px] xl:w-[23px] 2xl:w-[26px] 3xl:w-[31px]"
              alt="securitypaymen"
            />
            <Row className="bg-bluegray_100 justify-end lg:mt-[60px] xl:mt-[69px] 2xl:mt-[78px] 3xl:mt-[94px] xl:p-[11px] 2xl:p-[12px] 3xl:p-[15px] lg:p-[9px] rounded-radius20 shadow-bs1 w-[100%]">
              <Img
                src="images/img_appointment1.png"
                className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] lg:mb-[6px] xl:mb-[7px] 2xl:mb-[8px] 3xl:mb-[9px] mt-[1px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
                alt="appointmentTwo"
              />
              <Text className="font-normal ml-[4px] lg:mt-[3px] 2xl:mt-[4px] xl:mt-[4px] 3xl:mt-[5px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
                Medical Records
              </Text>
            </Row>
            <Img
              src="images/img_power2.png"
              className="lg:h-[19px] xl:h-[21px] 2xl:h-[24px] 3xl:h-[29px] lg:mt-[151px] xl:mt-[172px] 2xl:mt-[194px] 3xl:mt-[233px] lg:w-[18px] xl:w-[20px] 2xl:w-[23px] 3xl:w-[28px]"
              alt="powerTwo"
            />
          </Column>
        </Column>
      </Stack>
    </>
  );
};

export default FormPage;
