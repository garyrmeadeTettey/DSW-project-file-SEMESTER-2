import React from 'react';
import { useRef, useState } from "react";
import { BrowserRouter, Routes, Route, Link} from "react-router-dom";
import { login, useAuth } from "../firebase";

export default function Login(){
  const [ loading, setLoading ] = useState(false);
  const currentUser = useAuth();

  const emailRef = useRef();
  const passwordRef = useRef();


  async function handleLogin() {
    setLoading(true);
    try {
      await login(emailRef.current.value, passwordRef.current.value);
    } catch {
      alert("Error!");
    }
    setLoading(false);
  }

  return(
    <div>
 <div>Currently logged in as: { currentUser?.email } </div>

 <div id="fields">
        <input ref={emailRef} placeholder="Email" />
        <input ref={passwordRef} type="password" placeholder="Password" />
      </div>

      <button disabled={ loading || currentUser } onClick={handleLogin}>Log In</button>
   <Link to ="/signup">Signup </Link>"
    </div>
  )
}